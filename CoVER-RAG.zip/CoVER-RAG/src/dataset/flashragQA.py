"""Load the versioned FlashRAG data mirror used by this project."""
import json
import logging
import os
from pathlib import Path

from src.dataset.dataset import Item

log = logging.getLogger(__name__)
REPO_ROOT = Path(__file__).resolve().parents[2]
DEFAULT_REVISION = "64d4a872814da55c8284f5536795df03c39ddad2"


def resolve_flashrag_file(relative_path: str) -> str:
    """Prefer local data, then download the pinned file to the HF cache."""
    relative = Path(relative_path)
    if relative.is_absolute() or ".." in relative.parts:
        raise ValueError("Expected a relative path within the dataset repository")
    local_root = Path(os.getenv("FLASHRAG_DATASET_DIR") or "flashrag-dataset").expanduser()
    if not local_root.is_absolute():
        local_root = REPO_ROOT / local_root
    if relative.parts[0] == "retrieval-corpus" and os.getenv("FLASHRAG_CORPUS_DIR"):
        corpus_root = Path(os.environ["FLASHRAG_CORPUS_DIR"]).expanduser()
        if not corpus_root.is_absolute():
            corpus_root = REPO_ROOT / corpus_root
        local_path = corpus_root.joinpath(*relative.parts[1:])
    else:
        local_path = local_root / relative
    if local_path.is_file():
        return str(local_path)
    from huggingface_hub import hf_hub_download
    path = hf_hub_download(
        repo_id="cbxgss/rag",
        repo_type="dataset",
        revision=os.getenv("FLASHRAG_REVISION") or DEFAULT_REVISION,
        filename=relative.as_posix(),
    )
    log.info("Resolved dataset file: %s", relative)
    return path


def resolve_flashrag_jsonl(dataset: str, filename: str) -> str:
    return resolve_flashrag_file(f"{dataset}/{filename}")


def get_flashrag_qa(jsonl_path: str) -> list[Item]:
    with open(jsonl_path, "r", encoding="utf-8") as handle:
        items = [json.loads(line) for line in handle if line.strip()]
    return [
        Item(id=item["id"], question=item["question"],
             golden_answers=item["golden_answers"], metadata=item.get("metadata", {}))
        for item in items
    ]
