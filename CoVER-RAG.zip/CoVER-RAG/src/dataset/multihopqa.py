import os
import logging
import json
from src.dataset.dataset import Item, Dataset


log = logging.getLogger(__name__)


def get_multihopqa():
    dataset_path = os.path.join(
        os.getenv("HF_HOME"), "hub", "datasets--yixuantt--MultiHopRAG", "snapshots", "71ac0d0bd1f951d2d6b70311f7d2ae404e1ffa82",
        "MultiHopRAG.json"
    )
    with open(dataset_path, "r", encoding="utf-8") as f:
        items = json.load(f)
        data: list[Item] = [
            Item(
                id=i, question=item["query"], golden_answers=[item["answer"]],
                metadata={k: v for k, v in item.items() if k not in ["query", "answer"]}
            )
            for i, item in enumerate(items)
        ]
    dataset = Dataset(name="multihopqa", data=data)
    reanswer = """### Background

You will receive a question and its corresponding response. The response will be scored against a reference answer.

Because the score depends on how the answer is expressed, normalize the original response before scoring.

### Task

Carefully analyze the question and response, then convert the response into the standard answer format.

The following answer categories illustrate the standard answer format:

- 31.2% of answers are yes/no
- 16.9% of answers are dates, such as July 4, 1776
- 13.5% of answers are film titles, such as La La Land
- 11.7% of answers are personal names, such as George Washington
- 4.7% of answers are locations, such as New York City
- The remaining 22% of answers are usually entities in Wikidata

The categories above describe the answer distribution across the dataset. Here are concrete examples of questions and normalized answers:

Q: Which magazine was started first Arthur's Magazine or First for Women?
A: Arthur's Magazine

Q: The Oberoi family is part of a hotel company that has a head office in what city?
A: Delhi

Q: Musician and satirist Allie Goertz wrote a song about the \"The Simpsons\" character Milhouse, who Matt Groening named after who?
A: Richard Milhous Nixon

### Current question and response

Now carefully read the question and original response, and convert the response into the standard answer format.

Question:

{question}

Original response:

{response}

### Output format

Output only the normalized answer, with no additional content.
"""
    return dataset, reanswer
