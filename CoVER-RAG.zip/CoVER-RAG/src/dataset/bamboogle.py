from src.dataset.dataset import Dataset
from src.dataset.flashragQA import get_flashrag_qa


def get_bamboogle():
    dataset_path = "download/data/cbxgss/rag/bamboogle/test.jsonl"
    data = get_flashrag_qa(dataset_path)
    dataset = Dataset(name="bamboogle", data=data)
    reanswer = """### Background

You will receive a question and its corresponding response. The response will be scored against a reference answer.

Because the score depends on how the answer is expressed, normalize the original response before scoring.

### Task

Carefully analyze the question and response, then convert the response into the standard answer format.

The following answer categories illustrate the standard answer format:

- 30% of answers are personal names, such as King Edward VII, Rihanna
- 13% of answers are organization names, such as Cartoonito, Apalachee
- 10% of answers are locations, such as Fort Richardson, California
- 9% of answers are dates, such as 10th or even 13th century
- 8% of answers are numbers, such as 79.92 million, 17
- 8% of answers are works of art, such as Die schweigsame Frau
- 6% of answers are Yes/No
- 4% of answers are adjectives, such as conservative
- 1% of answers are events, such as Prix Benois de la Danse
- 6% of answers are proper nouns, such as Cold War, Laban Movement Analysis
- 5% of answers are common nouns, such as comedy, both men and women

The categories above describe the answer distribution across the dataset. Here are concrete examples of questions and normalized answers:

Q: Which magazine was started first Arthur's Magazine or First for Women?
A: Arthur's Magazine

Q: The Oberoi family is part of a hotel company that has a head office in what city?
A: Delhi

Q: Musician and satirist Allie Goertz wrote a song about the \"The Simpsons\" character Milhouse, who Matt Groening named after who?
A: Richard Milhous Nixon

### Current question and response

Now carefully read the question and original response, and convert the response into the standard answer format.

Question:

{question}

Original response:

{response}

### Output format

Output only the normalized answer, with no additional content.
"""
    return dataset, reanswer
