"""Reuse one LLM client per process."""

from functools import lru_cache


def prepare_llm_call_kwargs(model: str, **kwargs):
    params = dict(kwargs)
    if "qwen3" not in model.lower():
        return params

    extra_body = dict(params.get("extra_body") or {})
    chat_template_kwargs = dict(extra_body.get("chat_template_kwargs") or {})
    chat_template_kwargs.setdefault("enable_thinking", False)
    extra_body["chat_template_kwargs"] = chat_template_kwargs
    params["extra_body"] = extra_body
    return params


@lru_cache(maxsize=1)
def get_chater():
    from cr_utils import Chater

    return Chater()
