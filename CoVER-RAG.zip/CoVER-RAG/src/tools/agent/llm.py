import os
import logging
import asyncio
from src.tools.llm_client import get_chater, prepare_llm_call_kwargs


log = logging.getLogger(__name__)


class LLMAgent:
    def __init__(
        self,
        name: str,
        prompt: str,
        llm: str,
        response_format: dict = None,
        _log=True,
        default_openai_params: dict | None = None,
    ):
        self.name = name
        self.prompt = prompt
        self.llm = llm
        self.response_format = response_format
        self.log = _log
        self.default_openai_params = default_openai_params or {}

    def _get_timeout_s(self) -> float:
        """
        Per-agent timeout override.

        - Global default: LLM_REQUEST_TIMEOUT_S (default 60)
        - Per agent: LLM_REQUEST_TIMEOUT_S_<AGENT_NAME_UPPER>
          e.g. LLM_REQUEST_TIMEOUT_S_KS=180
        """
        base = os.getenv("LLM_REQUEST_TIMEOUT_S", "60")
        per_agent_key = f"LLM_REQUEST_TIMEOUT_S_{self.name.upper()}"
        return float(os.getenv(per_agent_key, base))

    def _get_max_retries(self) -> int:
        # Total attempts = 1 + max_retries
        return int(os.getenv("LLM_REQUEST_MAX_RETRIES", "1"))

    def _get_retry_backoff_s(self) -> float:
        return float(os.getenv("LLM_REQUEST_RETRY_BACKOFF_S", "0.5"))

    async def arun(self, id, placeholder: dict, openai_params: dict = None):
        openai_params = {**self.default_openai_params, **(openai_params or {})}
        messages = [
            {"role": "user", "content": self.prompt.format_map(placeholder)},
        ]
        if self.response_format:
            openai_params["response_format"] = self.response_format

        timeout_s = self._get_timeout_s()
        max_retries = self._get_max_retries()
        backoff_s = self._get_retry_backoff_s()

        last_exc: Exception | None = None
        for attempt in range(max_retries + 1):
            try:
                # Hard timeout to avoid indefinite hangs when the LLM endpoint accepts connections
                # but never responds (e.g. vLLM on :8013 wedged under load).
                rsp = await asyncio.wait_for(
                    get_chater().acall_llm(
                        prompt=messages,
                        model=self.llm,
                        name=self.name,
                        path=f"log/{id}/llm",
                        **prepare_llm_call_kwargs(self.llm, **openai_params),
                    ),
                    timeout=timeout_s,
                )
                return rsp
            except (asyncio.TimeoutError, asyncio.CancelledError) as e:
                # CancelledError can surface from lower-level clients when we time out.
                last_exc = e
                if attempt >= max_retries:
                    raise
                # Small backoff before retrying to avoid thundering herd.
                await asyncio.sleep(backoff_s * (2 ** attempt))
            except Exception as e:
                # Keep a conservative retry policy: only retry a couple times and then surface.
                last_exc = e
                if attempt >= max_retries:
                    raise
                await asyncio.sleep(backoff_s * (2 ** attempt))

        # Should be unreachable, but keep mypy happy.
        assert last_exc is not None
        raise last_exc

def prompt(path: str, en: bool = False) -> str:
    if en:
        path = path.replace("prompt", "prompt_en")
    with open(path, 'r') as file:
        return file.read()


async def atranslate(path: str) -> str:
    path_en = path.replace("prompt", "prompt_en")
    if not os.path.exists(path_en):
        os.makedirs(os.path.dirname(path_en), exist_ok=True)
        translate_prompt = """Translate the following prompt into English without changing its formatting.

{content}
"""
        translator = LLMAgent("translator", translate_prompt, "gpt-4o")
        prompt_zh = prompt(path)
        prompt_en = await translator.arun("trans", content=prompt_zh)
        with open(path_en, 'w') as file:
            file.write(prompt_en)
