import os
import requests
import aiohttp
import time
import json
import dotenv

# Ensure `.env` is loaded even when Hydra changes the working directory.
dotenv.load_dotenv(dotenv.find_dotenv(".env", usecwd=True), override=False)

url = os.getenv("web_retrieve_api_base", "")
api_key = os.getenv("web_retrieve_api_key", "")

headers = {
    'Authorization': f'Bearer {api_key}',
    'Content-Type': 'application/json'
}


def retrieve(query: str):
    payload = json.dumps({
        "query": query,
        "summary": True,
        "count": 10,
        "page": 1
    })
    start = time.time()
    session = requests.Session()
    session.trust_env = False
    results = session.post(url, headers=headers, data=payload).json()
    docs, scores, idxs = results["docs"], results["scores"], results["idxs"]
    rsp_time = time.time() - start
    return docs, scores, idxs

if __name__ == "__main__":
    docs, scores, idxs = retrieve("qwq?")
    print(docs, scores, idxs)
