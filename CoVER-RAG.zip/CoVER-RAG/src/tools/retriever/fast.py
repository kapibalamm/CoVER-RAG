import os
import requests
import aiohttp
import time
import dotenv
from tenacity import retry, stop_after_delay, wait_random_exponential
from cr_utils import CostManagers


# Ensure `.env` is loaded even when Hydra changes the working directory.
# (Hydra often runs under `outputs/...`, so relative ".env" may not resolve unless we search parents.)
dotenv.load_dotenv(dotenv.find_dotenv(".env", usecwd=True), override=False)


@retry(stop=stop_after_delay(120), wait=wait_random_exponential(multiplier=1, min=1, max=10), reraise=True)
def retrieve(source: str, query: str, topk: int = 10):
    data = {
        "source": source,
        "query": query,
        "topk": topk,
    }
    start = time.time()
    session = requests.Session()
    session.trust_env = False
    base = os.getenv("fastapi_retrieve")
    if not base:
        raise RuntimeError("Missing env var fastapi_retrieve (e.g. http://localhost:8011). Check your .env.")
    results = session.post(f"{base}/retrieve/", json=data, timeout=30).json()
    docs, scores, idxs = results["docs"], results["scores"], results["idxs"]
    rsp_time = time.time() - start
    CostManagers().update_cost(0, 0, 0, rsp_time, "tool_retrieve")
    return docs, scores, idxs


@retry(stop=stop_after_delay(120), wait=wait_random_exponential(multiplier=1, min=1, max=10), reraise=True)
async def aretrieve(source: str, query: str, topk: int = 10):
    async with aiohttp.ClientSession() as session:
        data = {
            "source": source,
            "query": query,
            "topk": topk,
        }
        start = time.time()
        base = os.getenv("fastapi_retrieve")
        if not base:
            raise RuntimeError("Missing env var fastapi_retrieve (e.g. http://localhost:8011). Check your .env.")
        async with session.post(
            f"{base}/retrieve/",
            json=data,
            timeout=aiohttp.ClientTimeout(total=30),
        ) as response:
            results = await response.json()
            docs, scores, idxs = results["docs"], results["scores"], results["idxs"]
            rsp_time = time.time() - start
            CostManagers().update_cost(0, 0, 0, rsp_time, "tool_retrieve")
            return docs, scores, idxs
