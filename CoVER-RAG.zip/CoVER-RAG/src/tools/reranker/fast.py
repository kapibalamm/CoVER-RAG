import os
import requests
import aiohttp
import time
import dotenv
from tenacity import retry, stop_after_delay, wait_random_exponential
from cr_utils import CostManagers


# Ensure `.env` is loaded even when Hydra changes the working directory.
dotenv.load_dotenv(dotenv.find_dotenv(".env", usecwd=True), override=False)


@retry(stop=stop_after_delay(120), wait=wait_random_exponential(multiplier=1, min=1, max=10), reraise=True)
def rerank(query: str, idxs: list[int], documents: list[str], k: int = 5, filter: bool = True) -> tuple[list[str], list[float], list[int]]:
    if len(idxs) == 0:
        return [], [], []
    data = {
        "query": query,
        "documents": documents,
    }
    start = time.time()
    session = requests.Session()
    session.trust_env = False
    base = os.getenv("fastapi_rerank")
    if not base:
        raise RuntimeError("Missing env var fastapi_rerank (e.g. http://localhost:8012). Check your .env.")
    scores = session.post(f"{base}/rerank/", json=data, timeout=30).json()
    ranked_docs = sorted(zip(idxs, documents, scores), key=lambda x: x[2], reverse=True)
    if filter:
        ranked_docs = [doc for doc in ranked_docs if doc[2] > 0]
    idxs = [idx for idx, _, _ in ranked_docs[:k]]
    scores = [score for _, _, score in ranked_docs[:k]]
    docs = [doc for _, doc, _ in ranked_docs[:k]]
    rsp_time = time.time() - start
    CostManagers().update_cost(0, 0, 0, rsp_time, "tool_rerank")
    return docs, scores, idxs


@retry(stop=stop_after_delay(120), wait=wait_random_exponential(multiplier=1, min=1, max=10), reraise=True)
async def arerank(query: str, idxs: list[int], documents: list[str], k: int = 5, filter: bool = True) -> tuple[list[str], list[float], list[int]]:
    if len(idxs) == 0:
        return [], [], []
    async with aiohttp.ClientSession() as session:
        data = {
            "query": query,
            "documents": documents,
        }
        start = time.time()
        base = os.getenv("fastapi_rerank")
        if not base:
            raise RuntimeError("Missing env var fastapi_rerank (e.g. http://localhost:8012). Check your .env.")
        async with session.post(
            f"{base}/rerank/",
            json=data,
            timeout=aiohttp.ClientTimeout(total=30),
        ) as response:
            scores = await response.json()
            ranked_docs = sorted(zip(idxs, documents, scores), key=lambda x: x[2], reverse=True)
            if filter:
                ranked_docs = [doc for doc in ranked_docs if doc[2] > 0]
            idxs = [idx for idx, _, _ in ranked_docs[:k]]
            scores = [score for _, _, score in ranked_docs[:k]]
            docs = [doc for _, doc, _ in ranked_docs[:k]]
            rsp_time = time.time() - start
            CostManagers().update_cost(0, 0, 0, rsp_time, "tool_rerank")
            return docs, scores, idxs
