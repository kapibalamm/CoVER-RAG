import os
import numpy as np
from openai.types import CreateEmbeddingResponse
import requests
import aiohttp
import dotenv
from tenacity import retry, stop_after_delay, wait_random_exponential


# Ensure `.env` is loaded even when Hydra changes the working directory.
dotenv.load_dotenv(dotenv.find_dotenv(".env", usecwd=True), override=False)


def _embed_base() -> str:
    base = os.getenv("fastapi_embed")
    if not base:
        raise RuntimeError("Missing env var fastapi_embed (e.g. http://localhost:8010). Check your .env.")
    return base.rstrip("/")


class FastApiEmbedder:
    @staticmethod
    def create_embedding(corpus: list[str], batch_size=1) -> np.ndarray:
        base = _embed_base()

        @retry(stop=stop_after_delay(120), wait=wait_random_exponential(multiplier=1, min=1, max=10), reraise=True)
        def ask_embedding(corpus: list[str]):
            response = requests.post(f"{base}/create_embedding/", json=corpus, proxies=None, timeout=30)
            response = CreateEmbeddingResponse(**response.json())
            return response

        response_embs = []
        for start_idx in range(0, len(corpus), batch_size):
            batch_data = corpus[start_idx:start_idx+batch_size]
            batch_embs: CreateEmbeddingResponse = ask_embedding(batch_data)
            response_embs += [emb.embedding for emb in batch_embs.data]
        response_embs = np.array(response_embs)
        return response_embs

    @staticmethod
    async def acreate_embedding(corpus: list[str], batch_size=1) -> np.ndarray:
        base = _embed_base()

        @retry(stop=stop_after_delay(120), wait=wait_random_exponential(multiplier=1, min=1, max=10), reraise=True)
        async def aask_embedding(corpus: list[str]):
            async with aiohttp.ClientSession() as session:
                async with session.post(f"{base}/create_embedding/", json=corpus, timeout=aiohttp.ClientTimeout(total=30)) as response:
                    data = await response.json()
                    response = CreateEmbeddingResponse(**data)
                    return response

        response_embs = []
        for start_idx in range(0, len(corpus), batch_size):
            batch_data = corpus[start_idx:start_idx+batch_size]
            batch_embs: CreateEmbeddingResponse = await aask_embedding(batch_data)
            response_embs += [emb.embedding for emb in batch_embs.data]
        response_embs = np.array(response_embs)
        return response_embs

    @staticmethod
    @retry(stop=stop_after_delay(120), wait=wait_random_exponential(multiplier=1, min=1, max=10), reraise=True)
    def get_dim():
        base = _embed_base()
        response = requests.get(f"{base}/get_dim/", timeout=10)
        return response.json()

    @staticmethod
    @retry(stop=stop_after_delay(120), wait=wait_random_exponential(multiplier=1, min=1, max=10), reraise=True)
    def get_max_seq_length():
        base = _embed_base()
        response = requests.get(f"{base}/get_max_seq_length/", timeout=10)
        return response.json()
