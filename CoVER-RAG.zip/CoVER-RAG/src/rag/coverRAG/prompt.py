from pydantic import BaseModel


shot_infer = """
## Output Format

You should output in JSON format:

{{
    "thought": "str, your reasoning thoughts",
    "need_retrieve": True / False
}}

## Example

### Example1

**Question**: Which magazine was started first Arthur's Magazine or First for Women?

**Known Knowledge**: None

**Reasoning History**: None

**Output**:

{{
    "thought": "I need to find out the founding dates of Arthur's Magazine and First for Women separately."
    "need_retrieve": True
}}

### Example2

**Question**: The Oberoi family is part of a hotel company that has a head office in what city?

**Known Knowledge**: None

**Reasoning History**: None

**Output**:

{{
    "thought": "I need to find out which hotel company the Oberoi family is part of."
    "need_retrieve": True
}}

### Example3

**Question**: The Oberoi family is part of a hotel company that has a head office in what city?

**Known Knowledge**:

- **Oberoi family**: The Oberoi family is an Indian family that is famous for its involvement in hotels, namely through The Oberoi Group.

**Reasoning History**:
1. I need to find out which hotel company the Oberoi family is part of.

**Output**:

{{
    "thought": "The Oberoi family is part of The Oberoi Group, which is an Indian hotel company. Next, I need to find out what city The Oberoi Group is headquartered in."
    "need_retrieve": True
}}
"""

prompt_infer = """## Background Information

Currently, there is a knowledge question-answering problem that needs to be solved, and retrieval tools can be used to find relevant knowledge to assist you in solving the problem.

For knowledge question-answering tasks, it is important to have a grasp of knowledge, which is organized by entities, with each entity having a segment of knowledge.

## Task Description

Your current task is to reason based on the knowledge that has been retrieved.

When reasoning, you must strictly adhere to the knowledge that has been retrieved to prevent errors.

There are two conditions for concluding your reasoning:
- You have obtained the answer you were seeking, at which point you can conclude your reasoning.
- You find that you cannot obtain the answer you want based solely on the retrieved knowledge and need to further expand your knowledge through retrieval tools.

## Note

- You must reason step by step carefully to ensure the rigor of the reasoning process.
- The knowledge used must be strictly based on the retrieved knowledge, and speculation is prohibited.
""" + shot_infer + """
## Question currently being solved

### Known Knowledge

{knowledge}

### Current Knowledge Question

{question}

### Reasoning History

{thought}

### Output

"""

class SchemaInfer(BaseModel):
    thought: str
    need_retrieve: bool

response_format_infer = {
    "type": "json_schema",
    "json_schema": {
        "name": "ThoughtProcess",
        "schema": SchemaInfer.model_json_schema()
    }
}


shot_need = """
## Output Format

You should output in JSON format:

{{
    "entities": [
        {{
            "entity": "str, The name of the entity.It often revolves around a noun-like entity, which can be a person, location, organization, event, or proper noun.",
            "keywords": ["str, retrieval query1 related to the entity", "str, retrieval query2", ...]
        }},
        ...
    ]
}}

## Example

### Example1

**Question**: Which magazine was started first Arthur's Magazine or First for Women?

**Known Knowledge**: None

**Reasoning History**: None

**Hint Entities**: "Arthur's Magazine"

**Output**:

{{
    "entities": [
        {{
            "entity": "Arthur's Magazine",
            "keywords": ["Arthur's Magazine", "Arthur's Magazine start date", "Arthur's Magazine founding date"]
        }},
        {{
            "entity": "First for Women",
            "keywords": ["First for Women", "First for Women start date", "First for Women founding date"]
        }}
    ]
}}

### Example2

**Question**: The Oberoi family is part of a hotel company that has a head office in what city?

**Known Knowledge**: None

**Reasoning History**: None

**Hint Entities**: None

**Output**:

{{
    "entities": [
        {{
            "entity": "Oberoi family",
            "keywords": ["Oberoi family", "Oberoi family hotel company", "Which hotel company is the Oberoi family part of"]
        }}
    ]
}}

### Example3

**Question**: The Oberoi family is part of a hotel company that has a head office in what city?

**Known Knowledge**:

- **Oberoi family**
    - The Oberoi family is an Indian family that is famous for its involvement in hotels, namely through The Oberoi Group.

**Reasoning History**: I have identified that the Oberoi family is part of The Oberoi Group, which is an Indian hotel company. Then I need to find out what city The Oberoi Group is headquartered in.

**Hint Entities**: "Oberoi family", "Indian", "The Oberoi Group"

**Output**:

{{
    "entities": [
        {{
            "entity": "The Oberoi Group",
            "keywords": ["The Oberoi Group", "Where is the head office of The Oberoi Group", "What city is The Oberoi Group headquartered in"]
        }}
    ]
}}
"""

shot_need = """
## Output Format

You should output in JSON format:

{{
    "entities": [
        {{
            "entity": "str, The name of the entity.It often revolves around a noun-like entity, which can be a person, location, organization, event, or proper noun.",
            "keywords": ["str, retrieval query1 related to the entity", "str, retrieval query2", ...]
        }},
        ...
    ]
}}

## Example

### Example1

**Question**: Who, according to articles in Sporting News, stand to make a profit by predicting outcomes such as a team's lead at the end of a quarter or the total points scored, and can also capitalize on event hype, like putting $130 on the Cowboys to potentially gain $100?

**Output**:

{{
    "entities": [
        {{
            "entity": "The person who can make a profit by predicting outcomes",
            "keywords": ["According to articles in Sporting News, who stands to make a profit by predicting outcomes such as a team's lead at the end of a quarter or the total points scored."]
        }},
        {{
            "entity": "The person who can capitalize on event hype to make a profit",
            "keywords": ["According to articles in Sporting News, Who can capitalize on event hype, like putting $130 on the Cowboys to potentially gain $100"]
        }}
    ]
}}

### Example2

**Question**: After the report by Fortune on October 4, 2023, regarding Sam Bankman-Fried's alleged use of Caroline Ellison as a front at Alameda Research, and the subsequent report by TechCrunch involving Sam Bankman-Fried's alleged motives for committing fraud, is the portrayal of Sam Bankman-Fried's actions by both news sources consistent?

**Output**:

{{
    "entities": [
        {{
            "entity": "Sam Bankman-Fried",
            "keywords": [
                "What's the portrayal of Sam Bankman-Fried's actions in the report by Fortune on October 4, 2023, regarding Sam Bankman-Fried's alleged use of Caroline Ellison as a front at Alameda Research?",
                "What's the portrayal of Sam Bankman-Fried's actions in the subsequent report by TechCrunch involving Sam Bankman-Fried's alleged motives for committing fraud?"
            ]
        }}
    ]
}}
"""

prompt_need = """## Background

Currently, there is a knowledge question that needs to be solved, and a retrieval tool can be used to find relevant knowledge to assist you in resolving the issue.

For knowledge question tasks, it is important to have a grasp of the knowledge, which is organized by entities, each of which has a segment of knowledge.

### Task Description

Your current task is to **identify what additional knowledge is needed** based on the given question, the existing knowledge, and the previous reasoning history, and to **generate retrieval keywords**.

**Identify What Additional Knowledge is Needed**

A knowledge point is a key piece of information necessary to solve the current problem. It often revolves around a noun-like entity, which can be a person, location, organization, event, or proper noun.

To help you identify the required knowledge, I will extract a list of entities from previous reasoning processes. These entities can help you pinpoint key knowledge points. They may not all be accurate, but they are generally helpful for guidance.

**Generate Retrieval Keywords**

- The generated retrieval keywords will be used by a dense retrieval tool. The keywords should meet the requirements of this tool to ensure relevant documents are retrieved.
- For the same knowledge point, it may be necessary to retrieve multiple sub-knowledge points. Ensure that the generated retrieval keywords cover all the required sub-knowledge points. However, focus only on the knowledge points relevant to the current question and avoid excessive retrieval.
- For a single sub-knowledge point, to improve the recall of relevant documents, you may need multiple retrieval keywords with the same meaning but different expressions. However, for similar-meaning keywords, retain at most **two variations**.


""" + shot_need + """
## Question currently being solved

### Known Knowledge

The knowledge that has been retrieved is as follows:

{knowledge}

### Question

The original question is as follows:

{question}

### Reasoning History

Your previous reasoning history is as follows:

{thought}

### Hint Entities

If you need to continue retrieving information on a previously generated knowledge point, ensure that the name of that specific knowledge point remains consistent. The knowledge points that have been retrieved are as follows:

{known_entity}

Use these entities as a reference to identify key knowledge points and generate retrieval keywords accordingly.

If the necessary knowledge points are unclear from the start, you may generate an additional knowledge point named "else" to store retrieval queries for such ambiguous knowledge.

{gaps_hint}

## Output
"""

class SchemaEIItem(BaseModel):
    entity: str
    keywords: list[str]

class SchemaEI(BaseModel):
    entities: list[SchemaEIItem]

response_format_need = {
    "type": "json_schema",
    "json_schema": {
        "name": "EntityKeywords",
        "schema": SchemaEI.model_json_schema()
    }
}


prompt_need_abl2 = """## Background

Currently, there is a knowledge question that needs to be solved, and a retrieval tool can be used to find relevant knowledge to assist you in resolving the issue.

### Task Description

Generate retrieval query based on current reasoning.

## Question currently being solved

### Question

The original question is as follows:

{question}

### Reasoning History

Your previous reasoning history is as follows:

{thought}

## Output

"""

class SchemaEIABL2(BaseModel):
    query: str

response_format_need_abl2 = {
    "type": "json_schema",
    "json_schema": {
        "name": "query",
        "schema": SchemaEIABL2.model_json_schema()
    }
}



shot_learn = """
## Example

### Example1

#### Question

Which magazine was started first Arthur's Magazine or First for Women?

#### Retrieval

Key Entity Retrieved: Arthur's Magazine

Retrieve Queries: When was Arthur's Magazine started?

Retrieved Documents:

##### First Arthur County Courthouse and Jail

The First Arthur County Courthouse and Jail, was perhaps the smallest court house in the United States, and serves now as a museum.

##### Arthur's Magazine

Arthur's Magazine (1844-1846) was an American literary periodical published in Philadelphia in the 19th century. Edited by T.S. Arthur, it featured work by Edgar A. Poe, J.H. Ingraham, Sarah Josepha Hale, Thomas G. Spear, and others. In May 1846 it was merged into "Godey's Lady's Book".

#### Output

Arthur's Magazine (1844-1846) was an American literary periodical published in Philadelphia in the 19th century.

### Example2

#### Question

Which magazine was started first Arthur's Magazine or First for Women?

#### Retrieval

Key Entity Retrieved: First for Women

Retrieve Queries: When was First for Women started?

Retrieved Documents:

##### Freeway Complex Fire

The Freeway Complex Fire was a 2008 wildfire in the Santa Ana Canyon area of Orange County, California. The fire started as two separate fires on November 15, 2008. The "Freeway Fire" started first shortly after 9am with the "Landfill Fire" igniting approximately 2 hours later. These two separate fires merged a day later and ultimately destroyed 314 residences in Anaheim Hills and Yorba Linda.

#### Output

None

### Example3

#### Question

Are director of film Move (1970 Film) and director of film Méditerranée (1963 Film) from the same country?

#### Retrieval

Key Entity Retrieved: Move (1970 film)

Retrieve Queries: Who directed the film Move (1970 film)?

Retrieved Documents:

##### Move (1970 film)

Move is a 1970 American comedy film starring Elliott Gould, Paula Prentiss and Geneviève Waïte, and directed by Stuart Rosenberg.
The screenplay was written by Joel Lieber and Stanley Hart, adapted from a novel by Lieber.

##### Output

Move is a 1970 American comedy film directed by Stuart Rosenberg.
"""

prompt_learn = """## Task Description

You are assisting in solving a QA problem, and you have gathered relevant information using retrieval tools.

Your task is to read and organize the retrieved documents, filtering out irrelevant content while summarizing information pertinent to the current problem. When assessing the usefulness of the content, consider that some information may not appear directly related to the final answer but could be essential for multi-hop reasoning. Even if content does not lead to an immediate conclusion, it may provide necessary context or intermediary insights that help progress toward the answer.

## Note

- Summarize the content directly without adding personal commentary or interpretations. Do not infer or speculate about missing information.
- Preserve the original wording for important content and **ensure that all entity names remain consistent with the original documents**.
""" + shot_learn + """
## Question currently being solved

### Original Question

{question}

### Reasoning History

{thought}

### Retrieval

Focus on extracting and summarizing information that relates to both the key entities and the aspects highlighted in the retrieve query. Emphasize connections that could facilitate multi-hop reasoning, ensuring that no potentially useful information is overlooked simply because it does not directly lead to the final answer.

The key entity, query, and retrieved content are provided below:

Key Entity Retrieved: {entity}

Retrieve Queries: {query}

Retrieved Content:

{docs}

### Output
"""

prompt_answer = """### Task Description

You are solving a knowledge-based question, and you have found relevant information using a retrieval tool to help you address the problem.

Now, you need to carefully read the retrieved relevant knowledge and summarize a complete answer based on your previous reasoning.

{grounding_anchor}### Retrieved Relevant Knowledge

{knowledge}

### Question Being Addressed

{question}

### Your Previous Reasoning

{thought}
"""

shot_sc = """
## Output Format

You should output in JSON format:

{{
    "required_facts": ["str, fact1 that must be known to answer the question", ...],
    "confirmed_facts": ["str, fact1 already present in the known knowledge", ...],
    "gaps": ["str, specific missing fact1 that still needs to be retrieved", ...],
    "direct_answer": "str, the exact answer to the question derived ONLY from confirmed_facts, or 'UNKNOWN' if it cannot be determined",
    "is_sufficient": true / false
}}

## Example

### Example1

**Question**: What city is the headquarters of the company that makes Agni-V?

**Known Knowledge**:
#### Manufacturer of Agni-V
The manufacturer of Agni-V is the Defence Research and Development Organisation (DRDO) of India.

**Output**:

{{
    "required_facts": [
        "Who manufactures Agni-V",
        "Where is the headquarters of the manufacturer of Agni-V"
    ],
    "confirmed_facts": [
        "The manufacturer of Agni-V is DRDO"
    ],
    "gaps": [
        "Where is the headquarters of DRDO"
    ],
    "direct_answer": "UNKNOWN",
    "is_sufficient": false
}}

### Example2

**Question**: What city is the headquarters of the company that makes Agni-V?

**Known Knowledge**:
#### Manufacturer of Agni-V
The manufacturer of Agni-V is the Defence Research and Development Organisation (DRDO) of India.

#### DRDO headquarters
DRDO is headquartered in New Delhi, India.

**Output**:

{{
    "required_facts": [
        "Who manufactures Agni-V",
        "Where is the headquarters of the manufacturer of Agni-V"
    ],
    "confirmed_facts": [
        "The manufacturer of Agni-V is DRDO",
        "DRDO is headquartered in New Delhi"
    ],
    "gaps": [],
    "direct_answer": "New Delhi",
    "is_sufficient": true
}}

### Example3 (CRITICAL: partial info ≠ sufficient)

**Question**: What is the name of the father of Edoardo Ponti?

**Known Knowledge**:
#### Edoardo Ponti
Edoardo Ponti is the son of Italian actress Sophia Loren.

**Output**:

{{
    "required_facts": [
        "Who is the father of Edoardo Ponti"
    ],
    "confirmed_facts": [
        "Edoardo Ponti is the son of Sophia Loren"
    ],
    "gaps": [
        "What is the name of Edoardo Ponti's father"
    ],
    "direct_answer": "UNKNOWN",
    "is_sufficient": false
}}

**Explanation**: Knowing the mother does NOT reveal the father's name. The father's name is a separate required fact. is_sufficient must be false.

### Example4 (CRITICAL: ambiguous type — must resolve type before answering)

**Question**: Were Coldplay's "Yellow" and Beethoven's "Moonlight Sonata" released in the same decade?

**Known Knowledge**:
#### Coldplay Yellow
"Yellow" is a song by British rock band Coldplay, released in June 2000.

#### Moonlight Sonata
Beethoven's "Moonlight Sonata" refers to Piano Sonata No. 14 in C♯ minor, Op. 27, No. 2, composed in 1801. There is also a 1937 film called "Moonlight Sonata".

**Output**:

{{
    "required_facts": [
        "Release decade of Coldplay's 'Yellow'",
        "Release decade of Beethoven's 'Moonlight Sonata' (the musical composition, not the film)"
    ],
    "confirmed_facts": [
        "Coldplay's 'Yellow' was released in June 2000, i.e. the 2000s decade",
        "Beethoven's 'Moonlight Sonata' (Piano Sonata No. 14) was composed in 1801, i.e. the 1800s decade"
    ],
    "gaps": [],
    "direct_answer": "No",
    "is_sufficient": true
}}

**Explanation**: When the question involves a work that could refer to multiple things (song vs. film, novel vs. opera), you MUST identify which type the question is asking about using the context, then confirm the correct fact. Do NOT leave the type ambiguous and mark is_sufficient false — resolve the type first, then answer.

### Example5 (CRITICAL: knowing two values ≠ comparison already done)

**Question**: Which country had a larger population in 2020, Canada or Australia?

**Known Knowledge**:
#### Canada population
Canada had a population of approximately 38 million in 2020.

#### Australia population
Australia had a population of approximately 26 million in 2020.

**Output**:

{{
    "required_facts": [
        "Population of Canada in 2020",
        "Population of Australia in 2020",
        "Which country has the larger population (comparison result)"
    ],
    "confirmed_facts": [
        "Canada's population in 2020 was approximately 38 million",
        "Australia's population in 2020 was approximately 26 million",
        "38 million > 26 million, therefore Canada had the larger population"
    ],
    "gaps": [],
    "direct_answer": "Canada",
    "is_sufficient": true
}}

**Explanation**: For comparison questions, you MUST explicitly perform the comparison in confirmed_facts and state the result. Knowing both values is necessary but not sufficient — the comparison must be completed and recorded. Only then may direct_answer be written and is_sufficient set to true.

### Example6 (CRITICAL: same name ≠ same entity)

**Question**: What nationality is the swimmer Sun Yang?

**Known Knowledge**:
#### Sun Yang
Sun Yang is a South Korean football player who plays as a midfielder for Jeonbuk Hyundai Motors FC.

**Output**:

{{
    "required_facts": [
        "What is the nationality of the swimmer Sun Yang"
    ],
    "confirmed_facts": [],
    "gaps": [
        "What is the nationality of the swimmer Sun Yang (not the South Korean football player)"
    ],
    "direct_answer": "UNKNOWN",
    "is_sufficient": false
}}

**Explanation**: The retrieved entity shares the same name but is a different person (football player, not swimmer). You must NOT use facts about a wrong entity even if names match. When the retrieved entity's description contradicts the role stated in the question, treat it as a name collision and keep the gap open.
"""

prompt_sc = """## Background

You are a rigorous evidence auditor helping to solve a multi-hop question-answering problem.

## Task Description

Your task is to audit whether the current known knowledge is **sufficient to answer the question**.

You must reason from the question outward — not from the knowledge inward. First decompose the question into the complete list of facts needed to answer it, then check each fact against the known knowledge.

## Rules

- **required_facts**: List every independent fact that must be known to answer the question. Be specific and concrete (e.g. "What city is DRDO headquartered in", not "more information about DRDO").
- **confirmed_facts**: List only facts that are explicitly stated in the known knowledge. Do NOT infer or assume facts not present. Knowing A relates to B does NOT confirm facts about B unless B's fact is stated explicitly.
- **gaps**: List every required fact that is NOT yet confirmed. Each gap must be a specific, searchable question (e.g. "Where did Franz Antel die", not "more information needed"). If no gaps, output an empty list.
- **direct_answer**: Write the exact answer to the question derived ONLY from confirmed_facts. If you cannot write a complete, direct answer (e.g. the answer is a specific name/date/place that is not yet known), you MUST write "UNKNOWN" and set is_sufficient to false.
- **is_sufficient**: Set to true ONLY when ALL of the following hold: (1) gaps is empty, (2) direct_answer is NOT "UNKNOWN", (3) the direct_answer concretely answers what the question asks. Otherwise false.
- **CRITICAL ANTI-PATTERN**: If the question asks for X's father and you only know X's mother, that is NOT sufficient. If the question asks for a death year and you only know a birth year, that is NOT sufficient. Partial biography ≠ complete answer.
- **AMBIGUOUS TYPE RULE**: If the question references a work (song, film, novel, opera, etc.) whose name could refer to multiple distinct entities of different types, you MUST first identify which type the question intends (using question wording and context), then confirm the fact for that specific type. Do NOT leave the type unresolved and mark is_sufficient false — resolve the type, then evaluate sufficiency.
- **COMPARISON COMPLETION RULE**: For any comparison question (larger/smaller, earlier/later, more/less, etc.), knowing the individual values of both sides is necessary but NOT sufficient. You MUST explicitly perform the comparison in confirmed_facts and state the result (e.g. "38M > 26M, therefore Canada has larger population"). Only after the comparison is recorded in confirmed_facts may you write the answer in direct_answer.
- **NAME COLLISION RULE**: If the retrieved entity shares the same name as the entity in the question but has a different identity (different role, different country, different era), you MUST NOT use any facts about that wrong entity. Treat all its facts as if they were not retrieved. Keep the gap open with a clarifying note (e.g. "nationality of swimmer Sun Yang, not the South Korean football player").
""" + shot_sc + """
## Question currently being solved

### Original Question

{question}

### Known Knowledge

{knowledge}

### Reasoning History

{thought}

## Output

"""

class SchemaSC(BaseModel):
    required_facts: list[str]
    confirmed_facts: list[str]
    gaps: list[str]
    direct_answer: str
    is_sufficient: bool

response_format_sc = {
    "type": "json_schema",
    "json_schema": {
        "name": "SufficiencyCheck",
        "schema": SchemaSC.model_json_schema()
    }
}


prompt_slot_facet_verifier = """## Background

You are a strict evidence-state gate for a multi-hop question-answering system.

The first sufficiency checker has proposed that the current evidence is enough. Your task is stricter: decide whether the proposed direct answer is supported by the numbered evidence sentences before the system is allowed to stop.

## Inputs

You will receive:
- the original question,
- a numbered sentence-level evidence context extracted from retrieved documents,
- the first sufficiency checker output.

## Verification Rules

- Write at most four compact checks. Each check should be one required claim or slot needed to justify the proposed answer.
- For each check, mark one of:
  - "supported": numbered evidence explicitly supports the check;
  - "missing": numbered evidence does not explicitly support the check;
  - "contradicted": numbered evidence conflicts with the proposed answer;
  - "type_mismatch": evidence is about a related but wrong type, role, relation, entity, time, or comparison target.
- A check may be "supported" only when you cite one or more evidence ids whose sentence text explicitly entails the check.
- Evidence ids are mandatory for every supported check. If you cannot cite evidence ids, the check is not supported.
- Be conservative. If a role or answer type is only loosely related, mark it missing or type_mismatch.
- Do not use outside knowledge. Do not infer facts that are not stated in the numbered evidence context.
- The final answer is supported only if all required checks are supported and the proposed answer concretely answers the original question.
- If the proposed answer is too broad, too narrow, wrong type, wrong relation, or only partially supported, reject stopping and produce specific searchable gaps.

## Common Failure Patterns To Catch

- Relation boundary: mother vs. father, spouse vs. parent, director vs. actor, headquarters vs. birthplace.
- Type boundary: writer/novelist/musician is not automatically the exact type asked unless the evidence explicitly supports the exact requested type. For yes/no questions asking whether both entities are "artists", "musicians", "actors", etc., each entity must have explicit evidence for that exact class or an unambiguous subclass of that class.
- Comparison boundary: both values must be known and the comparison result must be explicit.
- Long-chain boundary: a bridge entity is not enough; the final requested attribute of that bridge entity must also be supported.
- Name collision: same surface name is not enough when the role/context differs.

## Output Format

Return JSON only:

{{
    "checks": [
        {{
            "claim": "str, compact required claim or slot",
            "status": "supported | missing | contradicted | type_mismatch",
            "evidence_ids": ["str, cited evidence ids such as E1 or E7; empty if not supported"],
            "gap": "str, specific searchable missing/repair query if not supported, else empty string"
        }}
    ],
    "final_answer_supported": true / false,
    "revised_direct_answer": "str, exact supported answer if final_answer_supported is true, otherwise UNKNOWN",
    "gaps": ["str, specific searchable gaps to retrieve next if final_answer_supported is false"],
    "reason": "str, brief reason for the decision"
}}

## Original Question

{question}

## Numbered Evidence Context

{evidence_context}

## First Sufficiency Checker Output

{sc_output}

## Output

"""


class SchemaEvidenceCheck(BaseModel):
    claim: str
    status: str
    evidence_ids: list[str]
    gap: str


class SchemaSlotFacetVerifier(BaseModel):
    checks: list[SchemaEvidenceCheck]
    final_answer_supported: bool
    revised_direct_answer: str
    gaps: list[str]
    reason: str


response_format_slot_facet_verifier = {
    "type": "json_schema",
    "json_schema": {
        "name": "EvidenceStateSlotGate",
        "schema": SchemaSlotFacetVerifier.model_json_schema()
    }
}


prompt_infer_abl = """## Background

You serve as an intelligent assistant, adept at facilitating users through complex, multi-hop reasoning across multiple documents.

This task is illustrated through demonstrations, each consisting of a document set paired with a relevant question and its multi-hop reasoning thoughts.

## Task Description

Your task is to generate one thought for current step, DON'T generate the whole thoughts at once! If you reach what you believe to be the final step, start with "So the answer is:".'.

### Background Knowledge

{knowledge}

### Question: {question}

Thought: {thought}
"""
