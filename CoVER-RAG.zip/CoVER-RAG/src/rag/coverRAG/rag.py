import asyncio
from copy import deepcopy
from omegaconf import DictConfig
from tqdm.asyncio import tqdm
import json
import logging
import re
from cr_utils import Logger

from tenacity import retry, stop_after_delay, wait_random_exponential
from src.dataset import Item
from src.tools import LLMAgent, aretrieve, arerank
from src.rag.base import QA
from src.rag.coverRAG.doc import Doc, Docs
from src.rag.coverRAG.prompt import *
from src.startup import RAGBuilder


log = logging.getLogger(__name__)
# Classify evidence gaps conservatively before query generation.

_RELATION_WORDS = {"of", "whose", "that", "with", "from", "after", "before", "about", "between"}
_WH_WORDS = {"who", "what", "when", "where", "which", "how"}
_AUX_VERBS = {"is", "are", "was", "were", "does", "did", "has", "have", "had", "can", "could", "will", "would"}
_GENERIC_ENTITIES = {
    "person", "country", "city", "state", "league", "team", "winner",
    "producer", "director", "president", "manufacturer", "company",
    "organization", "place", "thing", "era", "year", "time", "area",
    "region", "location", "member", "leader", "founder", "owner",
}

_TYPE_ALIASES = {
    "singer": {"singer", "vocalist"},
}


def _classify_gap(gap: str) -> str:
    """Return 'simple' only when gap clearly names one entity + one attribute."""
    g = gap.strip().lower()
    tokens = g.split()
    rel_count = sum(1 for w in _RELATION_WORDS if f" {w} " in f" {g} ")
    wh_count = sum(1 for w in _WH_WORDS if g.startswith(w + " ") or f" {w} " in f" {g} ")

    if len(tokens) >= 10:
        return "complex"
    if rel_count >= 2:
        return "complex"
    if wh_count >= 2:
        return "complex"
    if "?" in gap and rel_count >= 2:
        return "complex"
    if tokens and tokens[0] in _AUX_VERBS:
        return "complex"
    if wh_count >= 1 and rel_count >= 1:
        return "complex"
    for w in _WH_WORDS:
        if not g.startswith(w + " ") and f" {w} " in g:
            return "complex"
    if g.startswith("who is the") or g.startswith("what is the"):
        return "complex"
    return "simple"


def _is_bad_normalized_entity(entity: str) -> bool:
    """True if entity looks like a generic placeholder after normalization."""
    e = entity.strip().lower()
    words = e.split()
    if not words:
        return True
    if len(words) <= 2 and words[0] in _GENERIC_ENTITIES:
        return True
    for head in _GENERIC_ENTITIES:
        if e.startswith(head + " of") or e.startswith(head + " where") or e.startswith(head + " who"):
            return True
    if any(w in words for w in ("is", "was", "are", "were", "did", "does")):
        return True
    return False


def _normalize_text(text: str) -> str:
    return " ".join(str(text).split())


def _tail_truncate(text: str, max_chars: int) -> str:
    text = str(text)
    if len(text) <= max_chars:
        return text
    return text[-max_chars:]


def _head_truncate(text: str, max_chars: int) -> str:
    text = str(text)
    if len(text) <= max_chars:
        return text
    return text[:max_chars].rstrip()


def _bridge_hint_excerpt(text: str, max_chars: int = 260) -> str:
    text = _normalize_text(text)
    if not text:
        return ""
    if len(text) <= max_chars:
        return text
    cut = text[:max_chars]
    boundary = max(cut.rfind(". "), cut.rfind("? "), cut.rfind("! "), cut.rfind("; "))
    if boundary >= max(60, max_chars // 2):
        return cut[: boundary + 1].rstrip()
    return cut.rstrip()


def _strip_gap_prefix(text: str) -> str:
    text = _normalize_text(text)
    prefixes = [
        r"^find\s+explicit\s+evidence\s+(?:that|for)\s*[:\-]?\s*",
        r"^find\s+evidence\s+(?:that|for)\s*[:\-]?\s*",
        r"^missing\s+evidence\s+(?:that|for)\s*[:\-]?\s*",
        r"^evidence\s+(?:that|for)\s*[:\-]?\s*",
    ]
    for pattern in prefixes:
        text = re.sub(pattern, "", text, flags=re.IGNORECASE).strip()
    return text.strip(" .")


def _coarsen_gap_text(text: str, max_chars: int = 160) -> str:
    text = _normalize_text(_strip_gap_prefix(text))
    text = re.sub(
        r"\b(?:what|which|who|where|when|how)\s+(?:is|was|are|were|did|does|do)\b",
        "",
        text,
        flags=re.IGNORECASE,
    )
    text = re.sub(
        r"\b(?:the|a|an)\s+(?:name|year|city|place|date)\s+of\b",
        "",
        text,
        flags=re.IGNORECASE,
    )
    text = _normalize_text(text.strip(" ?.,:;"))
    return _head_truncate(text, max_chars)


def _safe_json_object(text: str) -> dict:
    try:
        obj = json.loads(text)
        return obj if isinstance(obj, dict) else {}
    except (json.JSONDecodeError, TypeError, ValueError):
        pass

    match = re.search(r"\{.*\}", text or "", re.DOTALL)
    if not match:
        return {}
    try:
        obj = json.loads(match.group(0))
        return obj if isinstance(obj, dict) else {}
    except (json.JSONDecodeError, TypeError, ValueError):
        return {}


def _normalize_keywords(value) -> list[str]:
    if isinstance(value, str):
        raw = [value]
    elif isinstance(value, list):
        raw = value
    else:
        raw = []

    keywords = []
    for item in raw:
        keyword = _normalize_text(item)
        if keyword:
            keywords.append(_tail_truncate(keyword, 240))
    return keywords


def _split_sentences(text: str) -> list[str]:
    text = re.sub(r"\s+", " ", str(text)).strip()
    if not text:
        return []
    parts = re.split(r"(?<=[.!?])\s+", text)
    sentences = []
    for part in parts:
        part = part.strip()
        if len(part) < 20:
            continue
        sentences.append(_tail_truncate(part, 420))
    return sentences


def _token_set(text: str) -> set[str]:
    return {t for t in re.findall(r"[a-z0-9][a-z0-9_-]+", str(text).lower()) if len(t) > 2}


def _build_sc_context(kb, thought: list[str]) -> tuple[str, str]:
    """Keep SC input bounded so long-chain 2Wiki/MuSiQue cases do not exceed 32k."""
    knowledge_str = _tail_truncate(Knowledge.dict2str(kb), 12000)
    recent_thought = thought[-8:] if isinstance(thought, list) else []
    thought_str = _tail_truncate(
        "\n".join([f"{i + 1}. {t}" for i, t in enumerate(recent_thought)]),
        6000,
    )
    return knowledge_str, thought_str


def _asked_both_exact_type(question: str) -> str | None:
    q = str(question).lower()
    patterns = [
        r"\bboth\s+([a-z][a-z -]{2,30}?)(?:\?|$)",
        r"\bboth\s+(?:an?\s+)?([a-z][a-z -]{2,30}?)(?:\?|$)",
        r"\bare\s+.+?\s+both\s+(?:an?\s+)?([a-z][a-z -]{2,30}?)(?:\?|$)",
        r"\bwere\s+.+?\s+both\s+(?:an?\s+)?([a-z][a-z -]{2,30}?)(?:\?|$)",
    ]
    for pattern in patterns:
        match = re.search(pattern, q)
        if not match:
            continue
        type_phrase = match.group(1).strip(" ?.")
        words = type_phrase.split()
        if len(words) == 1:
            return words[0].rstrip("s")
    return None


def _type_terms(type_name: str) -> set[str]:
    base = type_name.strip().lower()
    if not base:
        return set()
    terms = {base, f"{base}s"}
    terms.update(_TYPE_ALIASES.get(base, set()))
    return terms


def _contains_type_term(text: str, type_name: str) -> bool:
    lowered = str(text).lower()
    return any(re.search(rf"\b{re.escape(term)}\b", lowered) for term in _type_terms(type_name))


def _evidence_sentence_map(evidence_context: str) -> dict[str, str]:
    evidence = {}
    for line in str(evidence_context).splitlines():
        match = re.match(r"^(E\d+)\s+(.+)$", line.strip())
        if match:
            evidence[match.group(1)] = match.group(2)
    return evidence


def _as_text_list(value) -> list[str]:
    if isinstance(value, list):
        return [_normalize_text(v) for v in value if _normalize_text(v)]
    if isinstance(value, str) and _normalize_text(value):
        return [_normalize_text(value)]
    return []


def _fallback_verifier_gaps(data: Item, sc_rsp: dict) -> list[str]:
    gaps = _as_text_list(sc_rsp.get("gaps"))
    if gaps:
        return gaps[:3]

    required = _as_text_list(sc_rsp.get("required_facts"))
    confirmed_text = " ".join(_as_text_list(sc_rsp.get("confirmed_facts"))).lower()
    fallback = []
    for fact in required:
        fact_tokens = _token_set(fact)
        confirmed_tokens = _token_set(confirmed_text)
        overlap = len(fact_tokens & confirmed_tokens)
        # Prefer facts that are not already mostly echoed by confirmed facts.
        if not fact_tokens or overlap < max(2, int(len(fact_tokens) * 0.6)):
            fallback.append(f"Find evidence for: {fact}")
    if not fallback and required:
        fallback.append(f"Find evidence for: {required[-1]}")

    answer = _normalize_text(sc_rsp.get("direct_answer", ""))
    if not fallback and answer and answer.upper() != "UNKNOWN":
        fallback.append(f"Find evidence that connects answer '{answer}' to the question: {data.question}")
    if not fallback:
        fallback.append(f"Find evidence needed to answer: {data.question}")
    return fallback[:3]


def _infer_slot_type(text: str) -> str:
    lowered = str(text).lower()
    is_complex = _classify_gap(text) == "complex"
    has_temporal = any(w in lowered for w in ("born", "died", "year", "date", "when", "age"))
    has_location = any(w in lowered for w in ("where", "place", "city", "country", "located", "location"))
    has_relation = any(w in lowered for w in ("father", "mother", "spouse", "wife", "husband", "child", "family"))
    has_type = any(w in lowered for w in ("type", "kind", "profession", "occupation", "genre", "is a", "was a", "both"))
    has_bridge = any(w in lowered for w in ("connect", "between", "of the", "whose", "that"))

    if is_complex:
        if has_type and not has_bridge and "both" in lowered:
            return "type"
        if has_temporal and not (has_location or has_relation or has_type or has_bridge):
            return "temporal"
        if has_relation and not has_bridge:
            return "relation"
        if has_location and not has_bridge:
            return "location"
        return "bridge"

    if has_temporal:
        return "temporal"
    if has_location:
        return "location"
    if has_relation:
        return "relation"
    if has_type:
        return "type"
    if has_bridge:
        return "bridge"
    return "answer_support"


def _slot_id(index: int) -> str:
    return f"S{index:02d}"


def _slot_key(raw_gap: str) -> str:
    return _tail_truncate(_normalize_text(raw_gap).lower(), 180)


def _make_slot(raw_gap: str, source: str, question: str, bridge_hint: str = "") -> dict:
    raw_gap = _tail_truncate(_normalize_text(raw_gap), 260)
    slot_type = _infer_slot_type(raw_gap)
    source_norm = _normalize_text(source).lower()
    target_query = _coarsen_gap_text(raw_gap, 160) if source_norm.startswith("ecv") else raw_gap
    return {
        "id": "",
        "raw_gap": raw_gap,
        "slot_type": slot_type,
        "source": source,
        "status": "active",
        "bridge_hint": _bridge_hint_excerpt(bridge_hint, 260),
        "question_hint": _tail_truncate(_normalize_text(question), 260),
        "target_query": _head_truncate(target_query or raw_gap, 180),
    }


def _slot_queries(slot: dict, question: str) -> list[str]:
    raw_gap = _normalize_text(slot.get("raw_gap", ""))
    slot_type = _normalize_text(slot.get("slot_type", "answer_support"))
    target_query = _normalize_text(slot.get("target_query", "")) or raw_gap
    bridge_hint = _normalize_text(slot.get("bridge_hint", ""))
    question = _normalize_text(question)
    if slot_type == "bridge":
        candidates = [
            bridge_hint or target_query,
            target_query,
            raw_gap,
            f"{bridge_hint} {target_query}" if bridge_hint else "",
        ]
    else:
        candidates = [
            target_query,
            f"{target_query} evidence",
            f"{question} {target_query}",
            f"{slot_type} evidence {target_query}",
        ]
    if bridge_hint:
        candidates.append(f"{bridge_hint} {target_query}")
    if slot_type == "type":
        candidates.append(f"{target_query} occupation profession type")
    elif slot_type == "relation":
        candidates.append(f"{target_query} family relation")
    elif slot_type == "temporal":
        candidates.append(f"{target_query} date year")
    elif slot_type == "location":
        candidates.append(f"{target_query} location place")

    queries = []
    seen = set()
    for query in candidates:
        query = _tail_truncate(_normalize_text(query), 260)
        key = query.lower()
        if query and key not in seen:
            queries.append(query)
            seen.add(key)
    return queries[:4]


def _slot_rerank_query(question: str, slot: dict, bridge_state: str, entity: str, keywords: list[str]) -> str:
    raw_gap = _normalize_text(slot.get("raw_gap", ""))
    slot_type = _normalize_text(slot.get("slot_type", "answer_support"))
    target_query = _normalize_text(slot.get("target_query", "")) or raw_gap
    base = _normalize_text(keywords[0] if keywords else entity)
    query = (
        f"Question: {question}\n"
        f"Evidence slot ({slot_type}): {target_query}\n"
        f"Current bridge state: {bridge_state}\n"
        f"Candidate query: {base}"
    )
    return _tail_truncate(query, 700)


def get_coverRAG_deterministic_openai_params(cfg: DictConfig) -> dict:
    return {
        "temperature": 0.0,
        "top_p": 1.0,
        "seed": int(cfg.get("seed", 0)),
    }


class Knowledge:
    def __init__(self, entity: str) -> None:
        self.entity: str = entity
        self.contents: list[str] = []
        self.supports: Docs = Docs()

    def __str__(self) -> str:
        return f"#### {self.entity}\n\n" + "\n\n".join(self.contents)

    @classmethod
    def dict2str(cls, knowledge: dict[str, "Knowledge"]) -> str:
        return "\n\n".join([str(k) for k in knowledge.values()])

    @classmethod
    def dict2json(cls, knowledge: dict[str, "Knowledge"]) -> dict:
        return deepcopy({k: v.contents for k, v in knowledge.items()})


class Infer(LLMAgent):
    def __init__(self, cfg: DictConfig) -> None:
        deterministic_openai_params = get_coverRAG_deterministic_openai_params(cfg)
        if cfg.task.method.abl.infer:
            super().__init__(
                "infer",
                prompt_infer_abl,
                cfg.task.method.infer,
                default_openai_params=deterministic_openai_params,
            )
        else:
            super().__init__(
                "infer",
                prompt_infer,
                cfg.task.method.infer,
                response_format_infer,
                default_openai_params=deterministic_openai_params,
            )
        self.cfg = cfg

    # Bound retries for unavailable LLM services.
    @retry(stop=stop_after_delay(120), wait=wait_random_exponential(multiplier=1, min=1, max=10), reraise=True)
    async def ainfer(self, id: str, placeholder: dict):
        if self.cfg.task.method.abl.infer:
            rsp = await self.arun(id, placeholder, openai_params={"stop": [".", "\n"]}) + "."
            need_retrieve = not "So the answer is" in rsp
            return rsp, need_retrieve, rsp
        else:
            rsp = await self.arun(id, placeholder)
            rsp = json.loads(rsp)
            thought, need_retrieve = rsp["thought"], rsp["need_retrieve"]
            return thought, need_retrieve, rsp


class KManager:
    def __init__(self, cfg: DictConfig) -> None:
        deterministic_openai_params = get_coverRAG_deterministic_openai_params(cfg)
        self.cfg = cfg
        self.kb: dict[str, Knowledge] = {}  # entity -> Knowledge
        self.thought: list[str] = []
        self.pending_gaps: list[str] = []   # gaps from last SC, fed into next EI round
        self.evidence_slots: list[dict] = []  # all gap/check slots observed in this query
        self.active_slots: list[dict] = []    # current retrieval targets
        self.sc_direct_answers: list[str] = []  # track SC direct_answers across rounds for consistency check
        self.agents = {
            "EI": (
                LLMAgent(
                    "EI",
                    prompt_need,
                    cfg.task.method.EI,
                    response_format_need,
                    default_openai_params=deterministic_openai_params,
                )
                if not cfg.task.method.abl.EI2 else
                LLMAgent(
                    "EI2",
                    prompt_need_abl2,
                    cfg.task.method.EI,
                    response_format_need_abl2,
                    default_openai_params=deterministic_openai_params,
                )
            ),
            "KS": LLMAgent(
                "KS",
                prompt_learn,
                cfg.task.method.KS,
                default_openai_params=deterministic_openai_params,
            ),
            "SC": LLMAgent(
                "SC",
                prompt_sc,
                cfg.task.method.SC,
                response_format_sc,
                default_openai_params=deterministic_openai_params,
            ),
            "ECV": LLMAgent(
                "ECV",
                prompt_slot_facet_verifier,
                cfg.task.method.SC,
                response_format_slot_facet_verifier,
                default_openai_params=deterministic_openai_params,
            ),
        }

    def _upsert_slot(self, slot: dict) -> dict:
        key = _slot_key(slot.get("raw_gap", ""))
        for existing in self.evidence_slots:
            if existing.get("key") == key:
                existing.update({
                    "source": slot.get("source", existing.get("source", "")),
                    "status": "active",
                    "slot_type": slot.get("slot_type", existing.get("slot_type", "answer_support")),
                    "bridge_hint": slot.get("bridge_hint", existing.get("bridge_hint", "")),
                    "question_hint": slot.get("question_hint", existing.get("question_hint", "")),
                    "target_query": slot.get("target_query", existing.get("target_query", "")),
                })
                return existing
        slot = deepcopy(slot)
        slot["id"] = _slot_id(len(self.evidence_slots) + 1)
        slot["key"] = key
        self.evidence_slots.append(slot)
        return slot

    def sync_slots_from_gaps(self, data: Item, gaps, source: str = "SC") -> None:
        gap_list = _as_text_list(gaps)[:3]  # Match the active-slot limit.
        if not gap_list:
            terminal_status = "resolved" if "accepted" in str(source).lower() else "inactive"
            for slot in self.active_slots:
                slot["status"] = terminal_status
            self.active_slots = []
            self.pending_gaps = []
            return
        bridge_hint = self.build_bridge_state(max_chars=260)
        active = []
        for gap in gap_list:
            slot = _make_slot(gap, source, data.question, bridge_hint)
            active.append(self._upsert_slot(slot))
        active_ids = {slot.get("id") for slot in active}
        for slot in self.evidence_slots:
            if slot.get("id") not in active_ids and slot.get("status") == "active":
                slot["status"] = "inactive"
        self.active_slots = active[:3]
        self.pending_gaps = [slot.get("target_query") or slot["raw_gap"] for slot in self.active_slots if slot.get("raw_gap")]

    def sync_slots_from_ecv(self, data: Item, ecv_rsp: dict) -> None:
        candidates = []
        for check in ecv_rsp.get("checks", []):
            if not isinstance(check, dict):
                continue
            status = str(check.get("status", "")).lower()
            if status == "supported":
                continue
            gap = _normalize_text(check.get("gap", "") or check.get("claim", ""))
            if gap:
                candidates.append({
                    "gap": gap,
                    "source": f"ECV:{status or 'missing'}",
                    "evidence_ids": check.get("evidence_ids", []),
                    "claim": _normalize_text(check.get("claim", "")),
                })
        for gap in _as_text_list(ecv_rsp.get("gaps", [])):
            candidates.append({"gap": gap, "source": "ECV:gaps", "evidence_ids": [], "claim": ""})

        seen = set()
        deduped = []
        for item in candidates:
            key = _slot_key(item["gap"])
            if key and key not in seen:
                deduped.append(item)
                seen.add(key)
        if not deduped:
            # Keep active slots when verification returns no replacement gaps.
            return

        bridge_hint = self.build_bridge_state(max_chars=260)
        active = []
        for item in deduped[:3]:  # Match the active-slot limit.
            slot = _make_slot(item["gap"], item["source"], data.question, bridge_hint)
            slot["claim"] = item.get("claim", "")
            slot["evidence_ids"] = item.get("evidence_ids", [])
            active.append(self._upsert_slot(slot))
        active_ids = {slot.get("id") for slot in active}
        for slot in self.evidence_slots:
            if slot.get("id") not in active_ids and slot.get("status") == "active":
                slot["status"] = "inactive"
        self.active_slots = active[:3]
        self.pending_gaps = [slot.get("target_query") or slot["raw_gap"] for slot in self.active_slots if slot.get("raw_gap")]

    def slot_queries_for_entity(self, data: Item, entity: str, keywords: list[str]) -> list[str]:
        normalized = _normalize_keywords(keywords)
        if not self.active_slots or not str(entity).startswith("Slot:"):
            return normalized
        match = re.search(r"\b(S\d+)\b", str(entity))
        slot = None
        if match:
            slot = next((s for s in self.active_slots if s.get("id") == match.group(1)), None)
        if slot is None:
            slot = self.active_slots[0]
        return _normalize_keywords(normalized + _slot_queries(slot, data.question))[:6]

    def build_bridge_state(self, max_chars: int = 900) -> str:
        parts = []
        if self.active_slots:
            slot_lines = [
                f"{slot.get('id')}:{slot.get('slot_type')}:{slot.get('raw_gap')}"
                for slot in self.active_slots[:3]
            ]
            parts.append("Active slots: " + " | ".join(slot_lines))
        if self.kb:
            entity_lines = []
            for entity, knowledge in list(self.kb.items())[-8:]:
                latest = knowledge.contents[-1] if knowledge.contents else ""
                entity_lines.append(f"{entity}: {_tail_truncate(_normalize_text(latest), 180)}")
            parts.append("Known evidence: " + " | ".join(entity_lines))
        if self.thought:
            parts.append("Recent thought: " + _tail_truncate(_normalize_text(self.thought[-1]), 180))
        return _tail_truncate("\n".join(parts), max_chars)

    def build_slot_rerank_query(self, data: Item, entity: str, keywords: list[str]) -> str:
        if not self.active_slots:
            return keywords[0] if keywords else entity
        match = re.search(r"\b(S\d+)\b", str(entity))
        if match:
            slot = next((s for s in self.active_slots if s.get("id") == match.group(1)), None)
            if slot:
                return _slot_rerank_query(data.question, slot, self.build_bridge_state(), entity, keywords)
        slot = self.active_slots[0]
        base = keywords[0] if keywords else entity
        target = slot.get("target_query") or slot.get("raw_gap")
        return _tail_truncate(
            f"Question: {data.question}\n"
            f"Current missing evidence slot: {target}\n"
            f"Candidate query: {base}",
            520,
        )

    def slot_trace(self) -> dict:
        visible_keys = {"id", "raw_gap", "slot_type", "source", "status", "bridge_hint", "claim", "evidence_ids", "target_query"}
        return {
            "active_slots": [
                {k: v for k, v in slot.items() if k in visible_keys}
                for slot in self.active_slots
            ],
            "all_slots": [
                {k: v for k, v in slot.items() if k in visible_keys}
                for slot in self.evidence_slots
            ],
        }

    # Same rationale as Infer: don't retry forever on LLM/network failures.
    @retry(stop=stop_after_delay(120), wait=wait_random_exponential(multiplier=1, min=1, max=10), reraise=True)
    async def aei(self, data: Item):
        if self.cfg.task.method.abl.EI:
            entity2key = {"none": [self.thought[-1]]}
            return entity2key
        elif self.cfg.task.method.abl.EI2:
            rsp = await self.agents["EI"].arun(data.id, placeholder={
                "question": data.question,
                "thought": "\n".join([f"{i + 1}. {t}" for i, t in enumerate(self.thought)]),
            })
            query_obj = _safe_json_object(rsp)
            query = query_obj.get("query", data.question)
            return {data.question: _normalize_keywords(query) or [data.question]}
        else:
            # Prioritize gaps from the previous sufficiency check.
            if self.pending_gaps:
                gaps_hint = (
                    "\n\n### Information Gaps (MUST PRIORITIZE)\n\n"
                    "The previous sufficiency check identified these specific missing facts. "
                    "Your PRIMARY goal this round is to retrieve EXACTLY these missing facts — do NOT expand to new entities.\n\n"
                    "For each gap below, generate keywords from **multiple angles**:\n"
                    "1. **Direct query**: entity name + missing attribute (e.g. 'X death year', 'X born where')\n"
                    "2. **Biographical context**: facts that co-occur with the missing fact (e.g. 'X biography', 'X career history')\n"
                    "3. **Event/attribute reframe**: rephrase from a different angle (e.g. 'X obituary', 'X (born YYYY)')\n\n"
                    "Do NOT repeat query expressions already used in previous steps. Stick strictly to the entities already identified.\n\n"
                    "Missing facts to retrieve:\n"
                    + "\n".join([f"- {g}" for g in self.pending_gaps])
                )
            else:
                gaps_hint = ""
            rsp = await self.agents["EI"].arun(data.id, placeholder={
                "knowledge": Knowledge.dict2str(self.kb),
                "question": data.question,
                "thought": "\n".join([f"{i + 1}. {t}" for i, t in enumerate(self.thought)]),
                "known_entity": [entity for entity in self.kb.keys() if entity != "else"],
                "gaps_hint": gaps_hint,
            })
            rsp_obj = _safe_json_object(rsp)
            raw_entities = rsp_obj.get("entities", [])
            entity2key = {}
            if isinstance(raw_entities, list):
                for item in raw_entities:
                    if not isinstance(item, dict):
                        continue
                    entity = _normalize_text(item.get("entity", ""))
                    keywords = _normalize_keywords(item.get("keywords", []))
                    if entity and keywords:
                        entity2key[_tail_truncate(entity, 120)] = keywords
            if not entity2key:
                if self.pending_gaps:
                    entity2key = {
                        f"Query: {_tail_truncate(g.strip(), 80)}": [g.strip()]
                        for g in self.pending_gaps[:3]
                        if g.strip()
                    }
                if not entity2key:
                    entity2key = {"else": [data.question]}

            # Hard injection postprocess: enforce GapGate results in code.
            # simple gap: allow EI entity normalization; complex gap: preserve raw bridge query.
            if self.pending_gaps:
                for gap in self.pending_gaps:
                    gap_type = _classify_gap(gap)
                    raw_gap = gap.strip()

                    if gap_type == "complex":
                        matched_entity = None
                        for ent in list(entity2key.keys()):
                            ent_lower = ent.lower()
                            gap_lower = raw_gap.lower()
                            if (len(ent_lower) > 3
                                    and not _is_bad_normalized_entity(ent)
                                    and ent_lower in gap_lower):
                                matched_entity = ent
                                break
                        if matched_entity:
                            entity2key[matched_entity] = _normalize_keywords(entity2key[matched_entity])
                            if raw_gap not in entity2key[matched_entity]:
                                entity2key[matched_entity].append(raw_gap)
                        else:
                            kb_key = f"Query: {raw_gap[:80]}"
                            if kb_key not in entity2key:
                                entity2key[kb_key] = [raw_gap]
                            else:
                                entity2key[kb_key] = _normalize_keywords(entity2key[kb_key])
                                if raw_gap not in entity2key[kb_key]:
                                    entity2key[kb_key].append(raw_gap)
                    else:
                        for ent in list(entity2key.keys()):
                            if _is_bad_normalized_entity(ent):
                                kb_key = f"Query: {raw_gap[:80]}"
                                if kb_key not in entity2key:
                                    entity2key[kb_key] = entity2key.pop(ent)
                                    entity2key[kb_key] = _normalize_keywords(entity2key[kb_key])
                                    if raw_gap not in entity2key[kb_key]:
                                        entity2key[kb_key].append(raw_gap)
                                break

            # Convert unresolved evidence slots into retrieval queries.
            if self.active_slots:
                for slot in self.active_slots[:3]:
                    slot_entity = f"Slot: {slot.get('id')} {slot.get('slot_type')}"
                    slot_keywords = _slot_queries(slot, data.question)
                    if slot_entity in entity2key:
                        entity2key[slot_entity] = _normalize_keywords(entity2key[slot_entity] + slot_keywords)
                    else:
                        entity2key[slot_entity] = slot_keywords

            return {
                entity: keywords
                for entity, keywords in (
                    (entity, _normalize_keywords(keywords))
                    for entity, keywords in entity2key.items()
                )
                if entity and keywords
            }

    @retry(stop=stop_after_delay(120), wait=wait_random_exponential(multiplier=1, min=1, max=10), reraise=True)
    async def asc(self, data: Item) -> dict:
        if self.cfg.task.method.abl.SC:
            return {"required_facts": [], "confirmed_facts": [], "gaps": [], "direct_answer": "UNKNOWN", "is_sufficient": False}
        knowledge_str, thought_recent = _build_sc_context(self.kb, self.thought)
        rsp = await self.agents["SC"].arun(data.id, placeholder={
            "question": data.question,
            "knowledge": knowledge_str,
            "thought": thought_recent,
        })
        _sc_default = {"required_facts": [], "confirmed_facts": [], "gaps": [], "direct_answer": "UNKNOWN", "is_sufficient": False}
        result = _safe_json_object(rsp) or _sc_default
        for key, default in _sc_default.items():
            if key not in result:
                result[key] = default
        # Track every non-UNKNOWN direct_answer for cross-round consistency.
        candidate = result.get("direct_answer", "UNKNOWN")
        if candidate and str(candidate).upper() != "UNKNOWN":
            self.sc_direct_answers.append(candidate)
        return result

    def build_evidence_context(self, data: Item, sc_rsp: dict, max_sentences: int = 16) -> str:
        focus = " ".join([
            data.question,
            str(sc_rsp.get("direct_answer", "")),
            " ".join(sc_rsp.get("required_facts", []) if isinstance(sc_rsp.get("required_facts"), list) else []),
            " ".join(sc_rsp.get("confirmed_facts", []) if isinstance(sc_rsp.get("confirmed_facts"), list) else []),
            " ".join(self.pending_gaps),
        ])
        focus_tokens = _token_set(focus)
        rows: list[tuple[int, int, str]] = []
        seq = 1
        seen_doc_ids: set = set()  # Deduplicate documents across entities.
        for entity, knowledge in self.kb.items():
            for doc in knowledge.supports:
                if doc.id in seen_doc_ids:
                    continue
                seen_doc_ids.add(doc.id)
                for sentence in _split_sentences(doc.content):
                    overlap = len(_token_set(sentence) & focus_tokens)
                    # Keep a small fallback pool even when lexical overlap is weak.
                    rows.append((overlap, seq, f"E{seq} [{doc.title}] {sentence}"))
                    seq += 1
                    if seq > 180:
                        break
                if seq > 180:
                    break
            if seq > 180:
                break
        if not rows:
            return "No numbered evidence sentences are available."

        rows.sort(key=lambda item: (-item[0], item[1]))
        selected = sorted(rows[:max_sentences], key=lambda item: item[1])
        context = "\n".join(row for _, _, row in selected)
        return _tail_truncate(context, 4000)

    @retry(stop=stop_after_delay(120), wait=wait_random_exponential(multiplier=1, min=1, max=10), reraise=True)
    async def aecv(self, data: Item, sc_rsp: dict) -> dict:
        evidence_context = self.build_evidence_context(data, sc_rsp)
        default = {
            "checks": [],
            "final_answer_supported": False,
            "revised_direct_answer": "UNKNOWN",
            "gaps": _fallback_verifier_gaps(data, sc_rsp),
            "reason": "verifier_parse_failed",
            "evidence_context": evidence_context,
        }
        try:
            rsp = await self.agents["ECV"].arun(
                data.id,
                placeholder={
                    "question": data.question,
                    "evidence_context": evidence_context,
                    "sc_output": json.dumps(sc_rsp, ensure_ascii=False),
                },
                openai_params={"max_tokens": 700},
            )
        except Exception as exc:
            result = deepcopy(default)
            result["reason"] = f"verifier_call_failed: {type(exc).__name__}"
            result["stop_decision"] = False
            return result
        parsed = _safe_json_object(rsp)
        result = parsed or deepcopy(default)
        if not parsed:
            result["stop_decision"] = False
            return result
        for key, value in default.items():
            if key not in result:
                result[key] = value
        if not isinstance(result.get("gaps"), list):
            result["gaps"] = _fallback_verifier_gaps(data, sc_rsp)
        result["gaps"] = _as_text_list(result.get("gaps")) or _fallback_verifier_gaps(data, sc_rsp)
        if not isinstance(result.get("checks"), list):
            result["checks"] = []
        asked_type = _asked_both_exact_type(data.question)
        evidence_by_id = _evidence_sentence_map(evidence_context)
        repaired_checks = []
        forced_gaps = []
        exact_type_mismatches = 0
        for check in result["checks"][:4]:
            if not isinstance(check, dict):
                continue
            if "claim" not in check and "facet" in check:
                check["claim"] = check.get("facet", "")
            if "status" not in check and "support_status" in check:
                check["status"] = check.get("support_status", "")
            if not isinstance(check.get("evidence_ids"), list):
                check["evidence_ids"] = []
            status = str(check.get("status", "")).lower()
            if status not in {"supported", "missing", "contradicted", "type_mismatch"}:
                status = "missing"
                check["status"] = status
            if status == "supported" and not check["evidence_ids"]:
                check["status"] = "missing"
                check["gap"] = check.get("gap") or check.get("claim", "missing cited evidence")
                status = "missing"
            if asked_type and status in {"supported", "type_mismatch"}:
                cited_text = " ".join(
                    evidence_by_id.get(str(eid), "")
                    for eid in check["evidence_ids"]
                )
                claim_text = str(check.get("claim", "")).lower()
                if asked_type in claim_text and _contains_type_term(cited_text, asked_type):
                    check["status"] = "supported"
                    check["gap"] = ""
                    status = "supported"
                elif status == "supported" and asked_type in claim_text:
                    check["status"] = "type_mismatch"
                    check["gap"] = check.get("gap") or f"Find explicit evidence that the entity is a {asked_type}."
                    if check["evidence_ids"]:
                        exact_type_mismatches += 1
                    status = "type_mismatch"
                elif status == "type_mismatch" and asked_type in claim_text and check["evidence_ids"]:
                    exact_type_mismatches += 1
            if str(check.get("status", "")).lower() != "supported":
                gap = _normalize_text(check.get("gap", "") or check.get("claim", ""))
                if gap:
                    forced_gaps.append(gap)
            repaired_checks.append(check)
        result["checks"] = repaired_checks
        if forced_gaps or not repaired_checks:
            result["final_answer_supported"] = False
            result["revised_direct_answer"] = "UNKNOWN"
            result["gaps"] = (forced_gaps or _fallback_verifier_gaps(data, sc_rsp))[:3]
        if asked_type and exact_type_mismatches:
            result["final_answer_supported"] = True
            result["revised_direct_answer"] = "No"
            result["negative_answer_supported"] = True
            result["gaps"] = []
            result["reason"] = (
                f"Exact type mismatch: at least one required entity is supported by evidence "
                f"as a different type, not as {asked_type}."
            )
        result["evidence_context"] = evidence_context
        result["stop_decision"] = coverRAG._ecv_accepts(result)
        if result["stop_decision"]:
            result["gaps"] = []
        return result

    def record_direct_answer(self, sc_rsp: dict) -> None:
        candidate = sc_rsp.get("direct_answer", "UNKNOWN")
        if candidate and str(candidate).upper() != "UNKNOWN":
            self.sc_direct_answers.append(candidate)

    async def aks(self, data: Item, entity: str, keywords: list[str], docs: Docs):
        if self.cfg.task.method.abl.KS:
            if "Related docs" not in self.kb:
                self.kb["Related docs"] = Knowledge("Related docs")
            new_docs = [doc for doc in docs if str(doc) not in self.kb["Related docs"].contents]
            self.kb["Related docs"].contents.extend([str(doc) for doc in new_docs])
            trace = {
                "new_docs": {doc.id: str(doc) for doc in new_docs},
                "summary": "abl_learn",
            }
            return trace
        if self.cfg.task.method.abl.EI:
            # EI ablation omits entities and keywords; infer the entity from doc.title when summarizing.
            entity2docs: dict[str, Docs] = {}
            for doc in docs:
                if doc.title not in entity2docs:
                    entity2docs[doc.title] = Docs()
                entity2docs[doc.title].add([doc])
            trace = {}
            for entity, docs in entity2docs.items():
                if entity not in self.kb:
                    self.kb[entity] = Knowledge(entity)
                new_docs = self.kb[entity].supports.add([doc for doc in docs])
                rsp = await self.agents["KS"].arun(data.id, placeholder={
                    "question": data.question,
                    "thought": "\n\n".join([f"#### step {i}\n\n{t}" for i, t in enumerate(self.thought)]),
                    "entity": entity,
                    "query": ", ".join(keywords),
                    "docs": "\n\n".join([str(doc) for doc in new_docs]),
                })
                if "None" not in rsp and "none" not in rsp:
                    self.kb[entity].contents.append(rsp)
                elif len(self.kb[entity].contents) == 0:
                    self.kb.pop(entity)
                trace[entity] = {
                    "new_docs": {idx: str(doc) for idx, doc in zip(new_docs.ids(), new_docs)},
                    "summary": rsp,
                }
            return trace
        else:
            if self.cfg.task.method.abl.KS:
                entity = "Related docs"
            if entity not in self.kb:
                self.kb[entity] = Knowledge(entity)
            new_docs = self.kb[entity].supports.add([doc for doc in docs])
            rsp = await self.agents["KS"].arun(data.id, placeholder={
                "question": data.question,
                "thought": "\n\n".join([f"#### step {i}\n\n{t}" for i, t in enumerate(self.thought)]),
                "entity": entity,
                "query": ", ".join(keywords),
                "docs": "\n\n".join([str(doc) for doc in new_docs]),
            })
            if  "None" not in rsp and "none" not in rsp:
                self.kb[entity].contents.append(rsp)
            elif len(self.kb[entity].contents) == 0:
                self.kb.pop(entity)
            trace = {
                "new_docs": {idx: str(doc) for idx, doc in zip(new_docs.ids(), new_docs)},
                "summary": rsp,
            }
            return trace


@RAGBuilder.register_module("coverRAG")
class coverRAG(QA):
    def __init__(self, cfg: DictConfig, logger: Logger):
        super().__init__(cfg, logger)
        deterministic_openai_params = get_coverRAG_deterministic_openai_params(cfg)
        self.infer = Infer(cfg)
        self.answer = LLMAgent(
            "answer",
            prompt_answer,
            cfg.task.base_llm,
            default_openai_params=deterministic_openai_params,
        )

    @staticmethod
    def _ecv_accepts(ecv_rsp: dict) -> bool:
        if ecv_rsp.get("negative_answer_supported") is True:
            return bool(ecv_rsp.get("final_answer_supported"))
        checks = ecv_rsp.get("checks", [])
        if not isinstance(checks, list) or not checks:
            return False
        for check in checks:
            if not isinstance(check, dict):
                return False
            if str(check.get("status", "")).lower() != "supported":
                return False
            if not check.get("evidence_ids"):
                return False
        return bool(ecv_rsp.get("final_answer_supported"))

    @staticmethod
    def _gate_sc_with_ecv(sc_rsp: dict, ecv_rsp: dict) -> dict:
        gated = deepcopy(sc_rsp)
        if coverRAG._ecv_accepts(ecv_rsp):
            revised = _normalize_text(ecv_rsp.get("revised_direct_answer", ""))
            if revised and revised.upper() != "UNKNOWN":
                gated["direct_answer"] = revised
            gated["is_sufficient"] = True
            gated["gaps"] = []
            return gated

        gaps = []
        for gap in ecv_rsp.get("gaps", []):
            gap = _normalize_text(gap)
            if gap:
                gaps.append(gap)
        if not gaps:
            for check in ecv_rsp.get("checks", []):
                if not isinstance(check, dict):
                    continue
                if str(check.get("status", "")).lower() == "supported":
                    continue
                gap = _normalize_text(check.get("gap", "") or check.get("claim", ""))
                if gap:
                    gaps.append(gap)
        if not gaps:
            gaps = [_normalize_text(g) for g in sc_rsp.get("gaps", []) if _normalize_text(g)]
        if not gaps:
            gaps = ["Find explicit evidence for the unsupported direct answer and all required question facts."]

        gated["is_sufficient"] = False
        gated["direct_answer"] = "UNKNOWN"
        gated["gaps"] = gaps[:3]
        return gated

    async def aquery(self, data: Item):
        log_dir = f"log/{data.id}/llm"
        self.logger.mkdir(log_dir)
        trace_tmp = {}
        kmanager = KManager(self.cfg)
        with tqdm(range(self.cfg.task.method.max_iter), leave=False, desc=f"{data.id}") as tbar:
            for step in tbar:
                log_step = {"knowledge": Knowledge.dict2json(kmanager.kb)}
                tbar.set_postfix(status="infer")
                thought_new, need_retrive, thought_rsp = await self.infer.ainfer(data.id, placeholder={
                    "knowledge": Knowledge.dict2str(kmanager.kb),
                    "question": data.question,
                    "thought": "\n".join(kmanager.thought),
                })
                kmanager.thought.append(thought_new)
                log_step["thought"] = thought_rsp
                if not need_retrive:
                    # Thought suggests stopping — but SC has final say
                    tbar.set_postfix(status="SC")
                    sc_rsp = await kmanager.asc(data)
                    log_step["SC"] = sc_rsp
                    kmanager.sync_slots_from_gaps(data, sc_rsp.get("gaps", []), source="SC")
                    log_step["slot_state"] = kmanager.slot_trace()
                    trace_tmp[step] = log_step
                    direct_answer = sc_rsp.get("direct_answer", "UNKNOWN")
                    if sc_rsp.get("is_sufficient", False) and direct_answer and direct_answer.upper() != "UNKNOWN":
                        ecv_rsp = await kmanager.aecv(data, sc_rsp)
                        log_step["ECV"] = ecv_rsp
                        sc_rsp = self._gate_sc_with_ecv(sc_rsp, ecv_rsp)
                        log_step["SC_after_ECV"] = sc_rsp
                        if sc_rsp.get("is_sufficient", False):
                            kmanager.sync_slots_from_gaps(data, [], source="ECV:accepted")
                        else:
                            kmanager.sync_slots_from_ecv(data, ecv_rsp)
                        log_step["slot_state"] = kmanager.slot_trace()
                        trace_tmp[step] = log_step
                        if sc_rsp.get("is_sufficient", False):
                            kmanager.record_direct_answer(sc_rsp)
                            break  # SC and ECV agree: stop
                        continue
                    continue  # SC disagrees: override Thought, continue retrieval
                tbar.set_postfix(status="EI")
                entity2key = await kmanager.aei(data)
                log_step["EI_slot_state"] = kmanager.slot_trace()
                tbar.set_postfix(status="retrieve")
                log_step["retrive"] = {}
                log_step["KS"] = {}
                for entity, keywords in entity2key.items():
                    if self.cfg.task.method.abl.EI:
                        entity = " ".join(keywords)
                    retrieve_keywords = kmanager.slot_queries_for_entity(data, entity, keywords)
                    log_step["retrive"][entity] = {
                        "r": {},
                        "base_keywords": keywords,
                        "effective_keywords": retrieve_keywords,
                    }
                    entity_docs = Docs()
                    for keyword in retrieve_keywords:
                        docs, scores, idxs = await aretrieve(self.cfg.corpus, keyword, self.cfg.task.method.retrieve.topk)
                        entity_docs.add([Doc(idx, doc) for idx, doc in zip(idxs, docs)])
                        log_step["retrive"][entity]["r"][keyword] = {
                            "docs": {idx: doc for idx, doc in zip(idxs, docs)},
                            "scores": {idx: score for idx, score in zip(idxs, scores)},
                        }
                    if not self.cfg.task.method.retrieve.rerank_abl:
                        docs, idxs = [str(doc) for doc in entity_docs], entity_docs.ids()
                        rerank_query = kmanager.build_slot_rerank_query(data, entity, retrieve_keywords)
                        docs, scores, idxs = await arerank(rerank_query, idxs, docs, k=self.cfg.task.method.retrieve.rerank_topk)
                        log_step["retrive"][entity]["rerank"] = {
                            "query": rerank_query,
                            "docs": {idx: doc for idx, doc in zip(idxs, docs)},
                            "scores": {idx: score for idx, score in zip(idxs, scores)},
                        }
                    docs_to_learn = Docs([Doc(idx, doc) for idx, doc in zip(idxs, docs)])
                    if len(docs_to_learn) == 0:
                        continue
                    trace_learn = await kmanager.aks(data, entity, retrieve_keywords, Docs([Doc(idx, doc) for idx, doc in zip(idxs, docs)]))
                    log_step["KS"][entity] = trace_learn
                # Check evidence sufficiency.
                tbar.set_postfix(status="SC")
                sc_rsp = await kmanager.asc(data)
                log_step["SC"] = sc_rsp
                kmanager.sync_slots_from_gaps(data, sc_rsp.get("gaps", []), source="SC")
                log_step["slot_state"] = kmanager.slot_trace()
                trace_tmp[step] = log_step
                # Only accept is_sufficient=true when direct_answer is also non-UNKNOWN
                direct_answer = sc_rsp.get("direct_answer", "UNKNOWN")
                if sc_rsp.get("is_sufficient", False) and direct_answer and direct_answer.upper() != "UNKNOWN":
                    ecv_rsp = await kmanager.aecv(data, sc_rsp)
                    log_step["ECV"] = ecv_rsp
                    sc_rsp = self._gate_sc_with_ecv(sc_rsp, ecv_rsp)
                    log_step["SC_after_ECV"] = sc_rsp
                    if sc_rsp.get("is_sufficient", False):
                        kmanager.sync_slots_from_gaps(data, [], source="ECV:accepted")
                    else:
                        kmanager.sync_slots_from_ecv(data, ecv_rsp)
                    log_step["slot_state"] = kmanager.slot_trace()
                    trace_tmp[step] = log_step
                    if sc_rsp.get("is_sufficient", False):
                        kmanager.record_direct_answer(sc_rsp)
                        break
        from collections import Counter

        sc_answers_counter = Counter(kmanager.sc_direct_answers) if kmanager.sc_direct_answers else Counter()
        cross_round_answer = None
        cross_round_count = 0
        if sc_answers_counter:
            most_common_answer, most_common_count = sc_answers_counter.most_common(1)[0]
            if most_common_count >= 2:
                cross_round_answer = most_common_answer
                cross_round_count = most_common_count

        last_step_data = list(trace_tmp.values())[-1] if trace_tmp else {}
        last_sc = last_step_data.get("SC_after_ECV", last_step_data.get("SC", {}))
        last_sufficient = last_sc.get("is_sufficient", False)
        last_direct = last_sc.get("direct_answer", "UNKNOWN")
        if last_direct and last_direct.upper() == "UNKNOWN":
            last_direct = None

        # Determine anchor level — SC controls stopping, not answering
        if last_sufficient and last_direct:
            grounding_anchor = (
                "### Sufficiency Checker Suggestion\n\n"
                f"The sufficiency checker suggests the answer may be: **{last_direct}**\n\n"
                "Consider this suggestion alongside the retrieved knowledge below, "
                "but verify it independently against the evidence. "
                "If the evidence contradicts this suggestion, trust the evidence.\n\n"
            )
        elif cross_round_answer:
            # WEAK: cross-round consistent but SC never reached is_sufficient=True
            grounding_anchor = (
                "### Grounding Hint (Cross-Round Consistency)\n\n"
                f"Across multiple reasoning rounds, the answer **{cross_round_answer}** "
                f"was derived {cross_round_count} times by the sufficiency checker, though sufficiency was not fully confirmed.\n\n"
                "You may wish to consider this repeated candidate answer, "
                "but use your own judgment based on the retrieved knowledge below.\n\n"
            )
        else:
            grounding_anchor = ""
        rsp = await self.answer.arun(data.id, placeholder={
            "knowledge": Knowledge.dict2str(kmanager.kb),
            "question": data.question,
            "thought": "\n\n".join([f"#### step {i}\n\n{t}" for i, t in enumerate(kmanager.thought)]),
            "grounding_anchor": grounding_anchor,
        })
        trace = {
            "knowledge": Knowledge.dict2json(kmanager.kb),
            "thought": kmanager.thought,
            "trace": trace_tmp,
        }
        return rsp, trace
