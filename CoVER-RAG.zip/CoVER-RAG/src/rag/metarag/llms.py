import os
import asyncio
from tenacity import retry, stop_after_delay, wait_random_exponential
from src.tools.llm_client import get_chater, prepare_llm_call_kwargs


class LLM:
    def __init__(self, llm_name:str):
        self.model_name = llm_name

    # Avoid infinite "hang" when the LLM endpoint is down/unresponsive.
    @retry(stop=stop_after_delay(120), wait=wait_random_exponential(multiplier=1, min=1, max=10), reraise=True)
    async def aget_output(self, id, cost_name: str, prompt, system_prompt="Act as an Evaluator & Critic System.", response_format: dict=None):
        message = [
            {"role": "system", "content": system_prompt},
            {"role": "user", "content": prompt}
        ]
        args = {"response_format": response_format} if response_format is not None else {}
        openai_params = {"temperature": 0.0, "max_tokens": 1024, **args}
        timeout_s = float(os.getenv("LLM_REQUEST_TIMEOUT_S", "60"))
        rsp = await asyncio.wait_for(
            get_chater().acall_llm(
                message,
                model=self.model_name,
                name=cost_name,
                path=f"log/{id}/llm",
                **prepare_llm_call_kwargs(self.model_name, **openai_params),
            ),
            timeout=timeout_s,
        )
        return rsp
