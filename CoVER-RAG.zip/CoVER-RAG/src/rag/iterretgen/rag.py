import asyncio
import os

from cr_utils import Logger
from omegaconf import DictConfig

from src.dataset import Item
from src.rag.base import QA
from src.startup import RAGBuilder
from src.tools import aretrieve, arerank
from src.tools.llm_client import get_chater, prepare_llm_call_kwargs


ITER_RETGEN_SYSTEM = """Answer the question based on the supplied documents.
Only give the answer and keep it concise."""

ITER_RETGEN_USER = """Question:
{question}

Retrieved documents:
{documents}

Current answer:"""


@RAGBuilder.register_module("iterretgen")
class IterRetGen(QA):
    """FlashRAG IterativePipeline adapted to the project's shared services."""

    def __init__(self, cfg: DictConfig, logger: Logger):
        super().__init__(cfg, logger)

    async def aquery(self, data: Item):
        log_dir = f"log/{data.id}/llm"
        self.logger.mkdir(log_dir)
        trace = {}
        previous_generation = ""

        for iteration in range(self.cfg.task.method.iter_num):
            if iteration == 0:
                retrieval_query = data.question
            else:
                retrieval_query = f"{data.question} {previous_generation}".strip()

            docs, retrieve_scores, idxs = await aretrieve(
                self.cfg.corpus,
                retrieval_query,
                self.cfg.task.method.retrieve.topk,
            )
            retrieve_trace = {
                "docs": {idx: doc for idx, doc in zip(idxs, docs)},
                "scores": {idx: score for idx, score in zip(idxs, retrieve_scores)},
            }

            docs, rerank_scores, idxs = await arerank(
                retrieval_query,
                idxs,
                docs,
                k=self.cfg.task.method.retrieve.rerank_topk,
                filter=self.cfg.task.method.retrieve.rerank_filter,
            )
            rerank_trace = {
                "docs": {idx: doc for idx, doc in zip(idxs, docs)},
                "scores": {idx: score for idx, score in zip(idxs, rerank_scores)},
            }

            previous_generation = await self._generate(
                data.id,
                data.question,
                docs,
                log_dir,
                iteration,
            )
            trace[iteration + 1] = {
                "retrieval_query": retrieval_query,
                "retrieve": retrieve_trace,
                "rerank": rerank_trace,
                "generation": previous_generation,
            }

        return previous_generation, trace

    async def _generate(
        self,
        item_id: str,
        question: str,
        docs: list[str],
        log_dir: str,
        iteration: int,
    ) -> str:
        documents = "\n\n".join(docs) if docs else "No documents were retrieved."
        messages = [
            {"role": "system", "content": ITER_RETGEN_SYSTEM},
            {
                "role": "user",
                "content": ITER_RETGEN_USER.format(
                    question=question,
                    documents=documents,
                ),
            },
        ]
        timeout_s = float(os.getenv("LLM_REQUEST_TIMEOUT_S", "60"))
        return await asyncio.wait_for(
            get_chater().acall_llm(
                prompt=messages,
                model=self.cfg.task.base_llm,
                name=f"iterretgen_{iteration + 1}",
                path=log_dir,
                **prepare_llm_call_kwargs(
                    self.cfg.task.base_llm,
                    temperature=0.0,
                    top_p=1.0,
                    seed=int(self.cfg.seed),
                    max_tokens=self.cfg.task.method.max_tokens,
                ),
            ),
            timeout=timeout_s,
        )
