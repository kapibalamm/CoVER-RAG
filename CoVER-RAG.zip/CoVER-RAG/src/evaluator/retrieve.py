import pytrec_eval


def retrieval_metrics(scores, relevance, k_values=None):
    """Compute retrieval metrics from query-to-document score and relevance mappings."""
    k_values = [1, 5, 10, 20, 50, 100] if k_values is None else k_values

    map_string = "map_cut." + ",".join([str(k) for k in k_values])
    ndcg_string = "ndcg_cut." + ",".join([str(k) for k in k_values])
    recall_string = "recall." + ",".join([str(k) for k in k_values])
    precision_string = "P." + ",".join([str(k) for k in k_values])

    evaluator = pytrec_eval.RelevanceEvaluator(
        relevance,
        {map_string, ndcg_string, recall_string, precision_string}
    )
    results = evaluator.evaluate(scores)

    ndcg = {}
    _map = {}
    recall = {}
    precision = {}

    for k in k_values:
        ndcg[f"ndcg@{k}"] = 0.0
        _map[f"map@{k}"] = 0.0
        recall[f"recall@{k}"] = 0.0
        precision[f"precision@{k}"] = 0.0

    for query_id in results.keys():
        for k in k_values:
            ndcg[f"ndcg@{k}"] += results[query_id]["ndcg_cut_" + str(k)]
            _map[f"map@{k}"] += results[query_id]["map_cut_" + str(k)]
            recall[f"recall@{k}"] += results[query_id]["recall_" + str(k)]
            precision[f"precision@{k}"] += results[query_id]["P_" + str(k)]

    for k in k_values:
        ndcg[f"ndcg@{k}"] = round(ndcg[f"ndcg@{k}"] / len(results), 5)
        _map[f"map@{k}"] = round(_map[f"map@{k}"] / len(results), 5)
        recall[f"recall@{k}"] = round(recall[f"recall@{k}"] / len(results), 5)
        precision[f"precision@{k}"] = round(precision[f"precision@{k}"] / len(results), 5)

    return {
        "recall": recall,
        "precision": precision,
        "ndcg": ndcg,
        "map": _map,
    }
