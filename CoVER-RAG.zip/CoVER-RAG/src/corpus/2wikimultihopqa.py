from src.dataset.flashragQA import resolve_flashrag_jsonl
import os
import logging
from tqdm import tqdm
from omegaconf import DictConfig
import json
import pickle as pkl

from src.corpus.utils import hash_object


log = logging.getLogger(__name__)


def load_corpus(cfg: DictConfig):
    log.info(f"loading corpus {cfg.corpus}")
    pkl_path = cfg.path.corpus_pkl
    if os.path.exists(pkl_path):
        log.info("loading corpus pkl")
        with open(pkl_path, "rb") as f:
            corpus = pkl.load(f)
    else:
        os.makedirs(cfg.workspace, exist_ok=True)
        log.info("loading corpus raw")
        raw_filepaths = [
            resolve_flashrag_jsonl("2wikimultihopqa", "train.jsonl"),
            resolve_flashrag_jsonl("2wikimultihopqa", "dev.jsonl"),
        ]
        used_full_ids, corpus = set(), []
        tbar1 = tqdm(raw_filepaths)
        for raw_filepath in tbar1:
            tbar1.set_postfix(file=raw_filepath)
            with open(raw_filepath, "r") as f:
                data = [json.loads(line) for line in f]
                tbar2 = tqdm(data, leave=False)
                for item in tbar2:
                    paragraphs = item["metadata"]["context"]
                    for i in range(len(paragraphs["title"])):
                        title = paragraphs["title"][i]
                        paragraph_text = " ".join(paragraphs["content"][i])
                        full_id = hash_object(" ".join([title, paragraph_text]))
                        if full_id in used_full_ids:
                            continue
                        used_full_ids.add(full_id)
                        doc = f"#### {title}\n\n{paragraph_text}"
                        corpus.append(doc)
        with open(pkl_path, "wb") as f:
            pkl.dump(corpus, f)
            log.info("saved corpus pkl")
    log.info(f"corpus length: {len(corpus)}")
    return corpus

