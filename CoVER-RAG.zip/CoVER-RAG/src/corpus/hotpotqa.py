from src.dataset.flashragQA import resolve_flashrag_file
import os
import logging
from tqdm import tqdm
from omegaconf import DictConfig
import json
import tarfile
import bz2
import pickle as pkl


log = logging.getLogger(__name__)


def load_corpus(cfg: DictConfig):
    log.info(f"loading corpus {cfg.corpus}")
    pkl_path = cfg.path.corpus_pkl
    if os.path.exists(pkl_path):
        log.info("loading corpus pkl")
        with open(pkl_path, "rb") as f:
            corpus = pkl.load(f)
    else:
        os.makedirs(cfg.workspace, exist_ok=True)
        log.info("loading corpus raw")
        base_path = resolve_flashrag_file(
            "retrieval-corpus/hotpotqa/enwiki-20171001-pages-meta-current-withlinks-abstracts.tar.bz2"
        )
        corpus = []
        with tarfile.open(base_path, "r:bz2") as tar:
            members = [m for m in tar.getmembers() if m.isfile() and os.path.basename(m.name).startswith("wiki_")]
            tbar1 = tqdm(members)
            for member in tbar1:
                tbar1.set_postfix(file=member.name)
                with bz2.open(tar.extractfile(member), "rt") as f:
                    tbar2 = tqdm(f, desc="Reading lines", leave=False)
                    for line in tbar2:
                        instance = json.loads(line.strip())
                        title = instance["title"]
                        sentences_text = [e.strip() for e in instance["text"]]
                        paragraph_text = " ".join(sentences_text)
                        doc = f"#### {title}\n\n{paragraph_text}"
                        corpus.append(doc)
                        tbar1.set_postfix(len=len(corpus))
        with open(pkl_path, "wb") as f:
            pkl.dump(corpus, f)
            log.info("saved corpus pkl")
    return corpus

