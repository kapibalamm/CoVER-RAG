import unittest
from pathlib import Path
from unittest.mock import AsyncMock, Mock, call, patch

from hydra import compose, initialize_config_dir
from src.startup import RAGBuilder
from src.dataset import Item
from src.rag.iterretgen import IterRetGen

ROOT = Path(__file__).resolve().parents[1]


class IterRetGenTests(unittest.IsolatedAsyncioTestCase):
    def setUp(self):
        with initialize_config_dir(config_dir=str(ROOT / 'config'), version_base=None):
            self.cfg = compose(config_name='main', overrides=['task/method=iterretgen'])
        self.logger = Mock()
        self.method = IterRetGen(self.cfg, self.logger)
        self.item = Item('example', 'Who founded the company?', ['PRIVATE_GOLD'], {})

    def test_registration(self):
        self.assertIs(RAGBuilder.get(self.cfg.task.method.name), IterRetGen)
        self.assertEqual(self.cfg.task.method.iter_num, 3)

    async def test_iteration_feedback_and_final_answer(self):
        client = Mock()
        client.acall_llm = AsyncMock(side_effect=['First answer', 'Second answer', 'Final answer'])
        documents = [f'Document {i}' for i in range(3)]
        responses = [([doc], [0.9], [i]) for i, doc in enumerate(documents)]
        with patch('src.rag.iterretgen.rag.aretrieve', new_callable=AsyncMock, side_effect=responses) as retrieve, \
                patch('src.rag.iterretgen.rag.arerank', new_callable=AsyncMock, side_effect=responses) as rerank, \
                patch('src.rag.iterretgen.rag.get_chater', return_value=client):
            answer, trace = await self.method.aquery(self.item)
        question = self.item.question
        queries = [question, f'{question} First answer', f'{question} Second answer']
        self.assertEqual(retrieve.await_args_list, [call(self.cfg.corpus, query, 50) for query in queries])
        self.assertEqual(answer, 'Final answer')
        self.assertEqual(list(trace), [1, 2, 3])
        for i, (query, generation) in enumerate(zip(queries, ['First answer', 'Second answer', 'Final answer'])):
            self.assertEqual(rerank.await_args_list[i], call(query, [i], [documents[i]], k=10, filter=True))
            self.assertEqual(trace[i + 1]['retrieval_query'], query)
            self.assertEqual(trace[i + 1]['generation'], generation)
            self.assertEqual(trace[i + 1]['rerank']['docs'], {i: documents[i]})
            params = client.acall_llm.await_args_list[i].kwargs
            prompt = params['prompt'][1]['content']
            self.assertIn(question, prompt)
            self.assertIn(documents[i], prompt)
            self.assertNotIn('PRIVATE_GOLD', str(params))
            for old_doc in documents[:i]:
                self.assertNotIn(old_doc, prompt)
            self.assertEqual(params['max_tokens'], 32)
            self.assertEqual(params['temperature'], 0.0)
            self.assertFalse(params['extra_body']['chat_template_kwargs']['enable_thinking'])
        self.logger.mkdir.assert_called_once_with('log/example/llm')

    async def test_single_round_without_documents(self):
        self.cfg.task.method.iter_num = 1
        client = Mock()
        client.acall_llm = AsyncMock(return_value='Unknown')
        with patch('src.rag.iterretgen.rag.aretrieve', new_callable=AsyncMock, return_value=([], [], [])), \
                patch('src.rag.iterretgen.rag.arerank', new_callable=AsyncMock, return_value=([], [], [])), \
                patch('src.rag.iterretgen.rag.get_chater', return_value=client):
            answer, trace = await self.method.aquery(self.item)
        self.assertEqual(answer, 'Unknown')
        self.assertEqual(list(trace), [1])
        self.assertEqual(trace[1]['retrieve']['docs'], {})
        self.assertIn('No documents were retrieved.', client.acall_llm.await_args.kwargs['prompt'][1]['content'])


if __name__ == '__main__':
    unittest.main()
