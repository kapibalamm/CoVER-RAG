"""Offline checks for method registration, evidence gates, and data portability."""
import os
import tempfile
import unittest
from pathlib import Path
from unittest.mock import patch

from hydra import compose, initialize_config_dir
from src.startup import RAGBuilder
from src.startup.run_rag import filter_dataset_by_sample_ids
from src.dataset.dataset import Dataset, Item
from src.rag.coverRAG import coverRAG
from src.dataset.flashragQA import DEFAULT_REVISION, resolve_flashrag_file

ROOT = Path(__file__).resolve().parents[1]


class ReleaseTests(unittest.TestCase):
    def test_method_configuration_and_registration(self):
        with initialize_config_dir(config_dir=str(ROOT / 'config'), version_base=None):
            cfg = compose(config_name='main', overrides=['task/method=coverRAG'])
        self.assertIs(RAGBuilder.get(cfg.task.method.name), coverRAG)
        self.assertEqual(cfg.task.method.max_iter, 5)
        self.assertEqual(cfg.task.method.retrieve.topk, 50)
        self.assertEqual(cfg.task.method.retrieve.rerank_topk, 10)

    def test_verification_requires_support_and_evidence_ids(self):
        self.assertFalse(coverRAG._ecv_accepts({'final_answer_supported': True, 'checks': []}))
        result = {'final_answer_supported': True,
                  'checks': [{'status': 'supported', 'evidence_ids': ['doc1:s1']}]}
        self.assertTrue(coverRAG._ecv_accepts(result))
        result['checks'][0]['evidence_ids'] = []
        self.assertFalse(coverRAG._ecv_accepts(result))
        result['checks'][0] = {'status': 'unsupported', 'evidence_ids': ['doc1:s1']}
        self.assertFalse(coverRAG._ecv_accepts(result))

    def test_failed_verification_reopens_gap_without_mutation(self):
        sc = {'is_sufficient': True, 'direct_answer': 'Alice', 'gaps': []}
        result = coverRAG._gate_sc_with_ecv(sc, {'checks': [], 'gaps': ['Find the spouse']})
        self.assertFalse(result['is_sufficient'])
        self.assertEqual(result['direct_answer'], 'UNKNOWN')
        self.assertEqual(result['gaps'], ['Find the spouse'])
        self.assertTrue(sc['is_sufficient'])

    def test_custom_sample_order(self):
        dataset = Dataset("example", [Item(str(i), "Question", ["Answer"], {}) for i in range(1001)])
        ids = [str(i) for i in range(999, -1, -1)]
        with tempfile.TemporaryDirectory() as folder:
            path = Path(folder) / "ids.txt"
            path.write_text("\n".join(ids))
            selected = filter_dataset_by_sample_ids(dataset, str(path))
        self.assertEqual([item.id for item in selected.data], ids)

    def test_invalid_sample_ids(self):
        dataset = Dataset("example", [Item("one", "Question", ["Answer"], {})])
        with tempfile.TemporaryDirectory() as folder:
            path = Path(folder) / "ids.txt"
            for content in ["", "one\none\n", "missing\n"]:
                with self.subTest(content=content):
                    path.write_text(content)
                    with self.assertRaises(ValueError):
                        filter_dataset_by_sample_ids(dataset, str(path))

    def test_local_data_precedes_download(self):
        with tempfile.TemporaryDirectory() as folder:
            path = Path(folder) / 'hotpotqa/dev.jsonl'
            path.parent.mkdir()
            path.write_text('{}\n')
            with patch.dict(os.environ, {'FLASHRAG_DATASET_DIR': folder}), \
                    patch('huggingface_hub.hf_hub_download') as download:
                self.assertEqual(resolve_flashrag_file('hotpotqa/dev.jsonl'), str(path))
                download.assert_not_called()

    def test_missing_data_uses_pinned_revision(self):
        with tempfile.TemporaryDirectory() as folder:
            with patch.dict(os.environ, {'FLASHRAG_DATASET_DIR': folder,
                                         'FLASHRAG_REVISION': DEFAULT_REVISION}), \
                    patch('huggingface_hub.hf_hub_download', return_value='/cache/dev.jsonl') as download:
                self.assertEqual(resolve_flashrag_file('musique/dev.jsonl'), '/cache/dev.jsonl')
                download.assert_called_once_with(repo_id='cbxgss/rag', repo_type='dataset',
                                                 revision=DEFAULT_REVISION, filename='musique/dev.jsonl')

    def test_separate_corpus_directory(self):
        with tempfile.TemporaryDirectory() as folder:
            path = Path(folder) / 'hotpotqa/corpus.tar.bz2'
            path.parent.mkdir()
            path.write_bytes(b'test')
            with patch.dict(os.environ, {'FLASHRAG_CORPUS_DIR': folder}):
                self.assertEqual(resolve_flashrag_file('retrieval-corpus/hotpotqa/corpus.tar.bz2'), str(path))


if __name__ == '__main__':
    unittest.main()
