#!/usr/bin/env bash
# Serve a local checkpoint or Hugging Face model through an OpenAI-compatible API.
set -euo pipefail
export CUDA_VISIBLE_DEVICES="${CUDA_VISIBLE_DEVICES:-0,1}"
model="${model:-Qwen/Qwen3-32B}"
served_model_name="${served_model_name:-${model}}"
IFS=',' read -ra devices <<< "${CUDA_VISIBLE_DEVICES}"
tensor_parallel_size="${TENSOR_PARALLEL_SIZE:-${#devices[@]}}"
extra_args=()
if [[ "${ENFORCE_EAGER:-1}" == "1" ]]; then
    extra_args+=(--enforce-eager)
fi
if [[ "${served_model_name,,}" == *qwen3* || "${model,,}" == *qwen3* ]]; then
    extra_args+=(--reasoning-parser qwen3)
fi
exec vllm serve "${model}" \
    --served-model-name "${served_model_name}" \
    --host "${HOST:-127.0.0.1}" \
    --port "${PORT:-8016}" \
    --tensor-parallel-size "${tensor_parallel_size}" \
    --pipeline-parallel-size 1 \
    --gpu-memory-utilization "${GPU_MEMORY_UTILIZATION:-0.95}" \
    --max-model-len "${MAX_MODEL_LEN:-8192}" \
    --dtype auto "${extra_args[@]}" "$@"
