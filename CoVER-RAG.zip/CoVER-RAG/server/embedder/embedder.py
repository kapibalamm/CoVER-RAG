import asyncio
import os
from typing import Optional

import dotenv
import torch
from fastapi import FastAPI, HTTPException
from fastapi.responses import JSONResponse
from openai.types import CreateEmbeddingResponse, Embedding
from sentence_transformers import SentenceTransformer


# Ensure `.env` is loaded even if working dir changes.
REPO_DIR = os.path.abspath(os.path.join(os.path.dirname(__file__), "..", ".."))
dotenv.load_dotenv(os.path.join(REPO_DIR, ".env"), override=False)

app = FastAPI()


class BgeEmbedder:
    def __init__(self, model_path="BAAI/bge-small-en-v1.5"):
        self.device = 'cuda' if torch.cuda.is_available() else 'cpu'
        model = SentenceTransformer(model_path)
        # NOTE: DataParallel often causes complexity with reload/fork; keep it single-process.
        self.model = model.to(self.device).eval()

    async def create_embedding(self, texts: list[str], *args, **kwargs):
        with torch.no_grad():
            embeddings = await asyncio.to_thread(self.model.encode, texts, *args, **kwargs)
            prompt_tokens = sum([len(sentence.split()) for sentence in texts])
            total_tokens = prompt_tokens
            return CreateEmbeddingResponse(
                data=[Embedding(embedding=embedding, index=i, object="embedding") for i, embedding in enumerate(embeddings)],
                model=self.model.__class__.__name__,
                object="list",
                usage={"prompt_tokens": prompt_tokens, "total_tokens": total_tokens}
            )

    def get_dim(self):
        return self.model.get_sentence_embedding_dimension()

    def get_max_seq_length(self):
        return self.model.get_max_seq_length()


_embedder: Optional[BgeEmbedder] = None
_embedder_lock = asyncio.Lock()


async def _get_embedder() -> BgeEmbedder:
    global _embedder
    if _embedder is not None:
        return _embedder
    async with _embedder_lock:
        if _embedder is not None:
            return _embedder
        model_path = os.getenv("EMBEDDER_MODEL_PATH", "BAAI/bge-small-en-v1.5")
        print(f"Loading model from {model_path} ...", flush=True)
        _embedder = await asyncio.to_thread(BgeEmbedder, model_path=model_path)
        print("Model loaded", flush=True)
        return _embedder


@app.on_event("startup")
async def _startup_load_model():
    # Preload model so early requests (even /get_dim) don't block behind a lazy init.
    await _get_embedder()


@app.get("/healthz")
async def healthz():
    # Always return quickly; indicates the web server loop is alive.
    return {"status": "ok"}


@app.post("/create_embedding/")
async def create_embedding(corpus: list[str]):
    embedder = await _get_embedder()
    ret = await embedder.create_embedding(corpus)
    # OpenAI types are Pydantic models; let FastAPI/JSONResponse serialize it.
    return JSONResponse(content=ret.model_dump())


@app.get("/get_dim/")
async def get_dim():
    embedder = await _get_embedder()
    return embedder.get_dim()


@app.get("/get_max_seq_length/")
async def get_max_seq_length():
    embedder = await _get_embedder()
    return embedder.get_max_seq_length()
