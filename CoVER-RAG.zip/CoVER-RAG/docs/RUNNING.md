# Running experiments

Run commands from the repository root with the environment activated. Each service occupies its own terminal or tmux window. Services bind to `127.0.0.1` by default; `HOST` and `PORT` override the bind address and port. If a service port changes, update its client setting too.

## Experiment options

```bash
BASE_LLM=Qwen/Qwen3-32B EVAL_LLM=Qwen/Qwen3-32B \
MODEL_TAG=qwen3-32b BATCH_SIZE=10 \
LLM_REQUEST_TIMEOUT_S=600 LLM_REQUEST_TIMEOUT_S_ECV=60 \
bash scripts/run_coverRAG.sh musique /path/to/musique.txt
```

Supported dataset names are `hotpotqa`, `2wikimultihopqa`, and `musique`. Supply a text file containing 1,000 unique development IDs of your choice, or pass `all` for the entire development set. Relative file paths are resolved from your current directory. `OUTPUT_ROOT` and `OUTPUT_DIR` override output locations.

For direct Hydra configuration:

```bash
python main.py task=rag dataset=hotpotqa task/method=coverRAG \
  task.base_llm=Qwen/Qwen3-32B task.eval_llm=Qwen/Qwen3-32B \
  task.sample_ids_path=/path/to/hotpotqa.txt \
  task.exp_size=1000 task.batch_size=10
```

## Other model routes

The model routes use these ports. Match the served model name exactly; local checkpoint directory names may differ.

| Model route | Port |
| --- | --- |
| `Qwen/Qwen2.5-7B-Instruct` | 8013 |
| `Qwen/Qwen2.5-72B-Instruct` | 8014 |
| `Qwen/Qwen3-8B` | 8015 |
| `Qwen/Qwen3-32B` | 8016 |
| `Llama-3.3-70B-Instruct` | 8017 |

For example, to use a smaller backbone while retaining the Qwen3-32B judge, keep the judge running and start a separate model server:

```bash
CUDA_VISIBLE_DEVICES=0 PORT=8015 \
model=/path/to/Qwen3-8B served_model_name=Qwen/Qwen3-8B \
bash server/vllm/run_qwen.sh

BASE_LLM=Qwen/Qwen3-8B EVAL_LLM=Qwen/Qwen3-32B \
bash scripts/run_all_coverRAG.sh /path/to/sample_ids
```

Allocate GPUs according to available memory; the example GPU assignments are configurable. `MAX_MODEL_LEN`, `GPU_MEMORY_UTILIZATION`, `TENSOR_PARALLEL_SIZE`, and `ENFORCE_EAGER` control the LLM launcher. It also accepts additional vLLM command-line arguments.

## Additional methods

The `task/method` choices include `direct`, `native`, `ircot`, `iterretgen`, `metarag`, and `genground`. MetaRAG requires its expert checkpoint via `METARAG_EXPERT_MODEL_PATH`; NER/NLI helpers are available on ports 8008/8009.

### Iter-RetGen

Iter-RetGen runs three retrieval-generation rounds by default. The first query is the question; later queries combine the question with the previous answer. The final round provides the output.

```bash
python main.py task=rag dataset=hotpotqa task/method=iterretgen \
  task.base_llm=Qwen/Qwen3-32B task.eval_llm=Qwen/Qwen3-32B \
  task.sample_ids_path=/path/to/hotpotqa.txt \
  task.exp_size=1000 task.batch_size=10
```

`task.method.iter_num` controls the round count and `task.method.max_tokens` controls the answer length. The defaults are 3 rounds and 32 tokens.

## Results

The runner saves `evaluate.csv` and per-question traces under the configured output directory. Inspect per-question `.error.json` files and the log before interpreting averages. The default metrics are exact match, token F1, inclusion match, and LLM judge accuracy.

