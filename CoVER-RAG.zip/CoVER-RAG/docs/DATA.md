# Data preparation

## QA datasets

Datasets are loaded from the `cbxgss/rag` Hugging Face repository. See the [setup commands](../README.md#prepare-data-and-indexes) for downloads and index construction.

The resolver first checks a local mirror, then uses the Hugging Face cache/download mechanism. To use existing data offline, set `FLASHRAG_DATASET_DIR` in `.env` to a directory containing:

```text
hotpotqa/train.jsonl
hotpotqa/dev.jsonl
2wikimultihopqa/train.jsonl
2wikimultihopqa/dev.jsonl
musique/train.jsonl
musique/dev.jsonl
retrieval-corpus/hotpotqa/enwiki-20171001-pages-meta-current-withlinks-abstracts.tar.bz2
```

`FLASHRAG_CORPUS_DIR` can point separately to the directory containing `hotpotqa/` and its Wikipedia archive. Relative paths are resolved against the repository root. Downloads are stored in the Hugging Face cache.

Each QA row contains `id`, `question`, `golden_answers`, and optional `metadata`. Corpus construction uses `metadata.context` for 2Wiki and `metadata.question_decomposition[*].support_paragraph` for MuSiQue.

## Corpus construction

HotpotQA reads the Wikipedia archive. The other two builders deduplicate paragraphs from train and development files. The embedding model defaults to `BAAI/bge-small-en-v1.5`; the index is FAISS Flat inner product.

Each dataset produces:

- `tmp/<dataset>.pkl`: ordered document strings.
- `tmp/<dataset>.memmap`: embeddings used during index construction.
- `tmp/<dataset>.index`: FAISS search index.

Existing artifacts are reused. Use a fresh workspace when changing the corpus or embedding model. For example, `python main.py task=corpus dataset=hotpotqa workspace=/path/to/new-indexes`; build the other datasets in that directory too, and set `COVER_RAG_INDEX_DIR=/path/to/new-indexes` for the retriever.

For prebuilt artifacts, provide matching `.pkl` and `.index` pairs for all three datasets. Document order, index row order, and the query embedding model must agree. The `.memmap` files are only needed for index construction.

## Evaluation data

See [Run experiments](../README.md#run-experiments) to select 1,000 development IDs or run the full development set.
