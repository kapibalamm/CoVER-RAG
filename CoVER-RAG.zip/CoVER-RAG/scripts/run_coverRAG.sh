#!/usr/bin/env bash

set -euo pipefail

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
REPO_DIR="$(cd "${SCRIPT_DIR}/.." && pwd)"

dataset="${1:-}"
selection="${2:-}"

if [[ $# -ne 2 ]]; then
  echo "Usage: $0 <hotpotqa|2wikimultihopqa|musique> <sample_ids.txt|all>" >&2
  exit 2
fi

case "${dataset}" in
  hotpotqa|2wikimultihopqa|musique) ;;
  *)
    echo "Unknown dataset: ${dataset}" >&2
    exit 2
    ;;
esac

sample_ids=""
if [[ "${selection}" == "all" ]]; then
  exp_size=0
  selection_name=all
else
  if [[ ! -f "${selection}" ]]; then
    echo "Sample ID file not found: ${selection}" >&2
    exit 1
  fi
  if ! awk '
    { gsub(/^[[:space:]]+|[[:space:]]+$/, "") }
    NF { count++; if (seen[$0]++) duplicate=1 }
    END { exit (count != 1000 || duplicate) }
  ' "${selection}"; then
    echo "Provide exactly 1000 unique sample IDs, one per line." >&2
    exit 1
  fi
  sample_ids="$(cd "$(dirname "${selection}")" && pwd)/$(basename "${selection}")"
  exp_size=1000
  selection_name=custom1000
fi

sanitize_model_tag() {
  local value="$1"
  value="${value##*/}"
  value="$(printf '%s' "${value}" | tr '[:upper:]' '[:lower:]')"
  value="$(printf '%s' "${value}" | sed -E 's/[^a-z0-9._-]+/-/g; s/^-+//; s/-+$//')"
  printf '%s' "${value:-model}"
}

METHOD_NAME="coverRAG"
BASE_LLM="${BASE_LLM:-Qwen/Qwen3-32B}"
EVAL_LLM="${EVAL_LLM:-${BASE_LLM}}"
MODEL_TAG="${MODEL_TAG:-$(sanitize_model_tag "${BASE_LLM}")}"
BATCH_SIZE="${BATCH_SIZE:-10}"
LLM_REQUEST_TIMEOUT_S="${LLM_REQUEST_TIMEOUT_S:-600}"
LLM_REQUEST_TIMEOUT_S_ECV="${LLM_REQUEST_TIMEOUT_S_ECV:-60}"
OUTPUT_ROOT="${OUTPUT_ROOT:-${REPO_DIR}/outputs}"
OUTPUT_DIR="${OUTPUT_DIR:-${OUTPUT_ROOT}/${MODEL_TAG}/${METHOD_NAME}}"
suffix="-${dataset}-${selection_name}-${METHOD_NAME}-${MODEL_TAG}"

cd "${REPO_DIR}"

export FLASHRAG_DATASET_DIR="${FLASHRAG_DATASET_DIR:-${REPO_DIR}/flashrag-dataset}"
export FLASHRAG_SPLIT=dev
export LLM_REQUEST_TIMEOUT_S
export LLM_REQUEST_TIMEOUT_S_ECV

echo "================================================================"
echo "Running ${METHOD_NAME}"
echo "repo=${REPO_DIR}"
echo "dataset=${dataset}"
echo "selection=${selection_name}"
echo "samples=${sample_ids}"
echo "exp_size=${exp_size}"
echo "batch_size=${BATCH_SIZE}"
echo "base_llm=${BASE_LLM}"
echo "eval_llm=${EVAL_LLM}"
echo "model_tag=${MODEL_TAG}"
echo "output_dir=${OUTPUT_DIR}"
echo "================================================================"

if [[ "${DRY_RUN:-0}" == "1" ]]; then
  echo "DRY_RUN=1, command was not executed."
  exit 0
fi

mkdir -p "${OUTPUT_DIR}"

python main.py \
  dataset="${dataset}" \
  task=rag \
  task/method=coverRAG \
  task.base_llm="${BASE_LLM}" \
  task.eval_llm="${EVAL_LLM}" \
  task.batch_size="${BATCH_SIZE}" \
  task.exp_size="${exp_size}" \
  "task.sample_ids_path='${sample_ids}'" \
  "task.suffix='${suffix}'" \
  "log_config.log_dir='${OUTPUT_DIR}'"
