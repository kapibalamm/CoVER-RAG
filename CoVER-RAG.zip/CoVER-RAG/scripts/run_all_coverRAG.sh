#!/usr/bin/env bash

set -euo pipefail

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
selection="${1:-}"

if [[ $# -ne 1 ]]; then
  echo "Usage: $0 <sample_directory|all>" >&2
  exit 2
fi

for dataset in hotpotqa 2wikimultihopqa musique; do
  sample_ids="${selection}"
  if [[ "${selection}" != "all" ]]; then
    sample_ids="${selection}/${dataset}.txt"
  fi
  DRY_RUN=1 bash "${SCRIPT_DIR}/run_coverRAG.sh" "${dataset}" "${sample_ids}" > /dev/null
done

for dataset in hotpotqa 2wikimultihopqa musique; do
  sample_ids="${selection}"
  if [[ "${selection}" != "all" ]]; then
    sample_ids="${selection}/${dataset}.txt"
  fi
  bash "${SCRIPT_DIR}/run_coverRAG.sh" "${dataset}" "${sample_ids}"
done
