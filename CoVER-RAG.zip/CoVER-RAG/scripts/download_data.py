"""Download the versioned QA files and optional HotpotQA corpus."""
import argparse
import sys
from pathlib import Path

REPO_ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(REPO_ROOT))


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--datasets', nargs='+', default=['hotpotqa', '2wikimultihopqa', 'musique'],
                        choices=['hotpotqa', '2wikimultihopqa', 'musique'])
    parser.add_argument('--splits', nargs='+', default=['train', 'dev'], choices=['train', 'dev'])
    parser.add_argument('--hotpot-corpus', action='store_true', help='Also download the Wikipedia archive')
    args = parser.parse_args()
    import dotenv
    dotenv.load_dotenv(REPO_ROOT / '.env')
    from src.dataset.flashragQA import resolve_flashrag_file
    for dataset in args.datasets:
        for split in args.splits:
            print(resolve_flashrag_file(f'{dataset}/{split}.jsonl'))
    if args.hotpot_corpus:
        print(resolve_flashrag_file(
            'retrieval-corpus/hotpotqa/enwiki-20171001-pages-meta-current-withlinks-abstracts.tar.bz2'))


if __name__ == '__main__':
    main()
